'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Chapitre3() {
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const [completedExercises, setCompletedExercises] = useState<string[]>([]);

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const toggleExercise = (exerciseId: string) => {
    setCompletedExercises(prev => 
      prev.includes(exerciseId) 
        ? prev.filter(id => id !== exerciseId)
        : [...prev, exerciseId]
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      {/* Header Navigation */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-emerald-600 cursor-pointer">
              <span className="font-['Pacifico']">StressWell</span>
            </Link>
            <div className="flex items-center space-x-6">
              <Link href="/table-des-matieres" className="text-gray-600 hover:text-emerald-600 transition-colors cursor-pointer">Table des matières</Link>
              <Link href="/outils-pratiques" className="text-gray-600 hover:text-emerald-600 transition-colors cursor-pointer">Outils</Link>
              <Link href="/ressources" className="text-gray-600 hover:text-emerald-600 transition-colors cursor-pointer">Ressources</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Chapter Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center bg-emerald-100 text-emerald-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <i className="ri-leaf-line mr-2"></i>
            Chapitre 3
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            Nutrition et habitudes de vie pour la résilience
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Découvrez comment l'alimentation, le sommeil et l'activité physique influencent directement votre capacité à gérer le stress
          </p>
          <div className="flex items-center justify-center mt-4 text-sm text-gray-500">
            <i className="ri-time-line mr-1"></i>
            <span>18 minutes de lecture</span>
            <span className="mx-2">•</span>
            <i className="ri-bookmark-line mr-1"></i>
            <span>Plans nutritionnels inclus</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="bg-white rounded-lg p-4 mb-8 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Progression du chapitre</span>
            <span className="text-sm text-emerald-600">75% complété</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-emerald-500 h-2 rounded-full" style={{width: '75%'}}></div>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          
          {/* Introduction */}
          <div className="p-8">
            <div className="bg-emerald-50 rounded-lg p-6 mb-8">
              <h2 className="text-2xl font-bold text-emerald-800 mb-4 flex items-center">
                <i className="ri-heart-pulse-line mr-3"></i>
                L'équation corps-esprit
              </h2>
              <p className="text-emerald-700 leading-relaxed">
                Notre résilience au stress ne dépend pas uniquement de notre mental. Notre corps, à travers l'alimentation, 
                le sommeil et l'exercice, joue un rôle fondamental dans notre capacité à faire face aux défis quotidiens. 
                Ce chapitre vous révèle les liens scientifiques entre nutrition et gestion du stress.
              </p>
            </div>

            {/* Section 1: Nutrition Anti-Stress */}
            <div className="mb-8">
              <button
                onClick={() => toggleSection('nutrition')}
                className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <div className="flex items-center">
                  <i className="ri-restaurant-line text-emerald-600 text-xl mr-3"></i>
                  <h3 className="text-xl font-semibold text-gray-800">1. Les fondamentaux de la nutrition anti-stress</h3>
                </div>
                <i className={`ri-arrow-${expandedSection === 'nutrition' ? 'up' : 'down'}-line text-gray-500`}></i>
              </button>
              
              {expandedSection === 'nutrition' && (
                <div className="mt-4 p-6 bg-white border border-gray-100 rounded-lg">
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-3">🧠 Micronutriments essentiels</h4>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="bg-emerald-50 p-4 rounded-lg">
                          <h5 className="font-medium text-emerald-800 mb-2">Magnésium</h5>
                          <p className="text-sm text-emerald-700 mb-2">Régule le système nerveux et réduit l'inflammation</p>
                          <p className="text-xs text-emerald-600">Sources: épinards, amandes, avocat, chocolat noir</p>
                        </div>
                        <div className="bg-blue-50 p-4 rounded-lg">
                          <h5 className="font-medium text-blue-800 mb-2">Oméga-3</h5>
                          <p className="text-sm text-blue-700 mb-2">Protègent contre l'inflammation et stabilisent l'humeur</p>
                          <p className="text-xs text-blue-600">Sources: poissons gras, noix, graines de lin</p>
                        </div>
                        <div className="bg-orange-50 p-4 rounded-lg">
                          <h5 className="font-medium text-orange-800 mb-2">Vitamine B complexe</h5>
                          <p className="text-sm text-orange-700 mb-2">Soutiennent la production de neurotransmetteurs</p>
                          <p className="text-xs text-orange-600">Sources: légumineuses, céréales complètes, œufs</p>
                        </div>
                        <div className="bg-purple-50 p-4 rounded-lg">
                          <h5 className="font-medium text-purple-800 mb-2">Antioxydants</h5>
                          <p className="text-sm text-purple-700 mb-2">Combattent le stress oxydatif</p>
                          <p className="text-xs text-purple-600">Sources: baies, thé vert, légumes colorés</p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-800 mb-3">⚡ Équilibre glycémique</h4>
                      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                        <p className="text-yellow-800 mb-2">
                          <strong>Principe clé:</strong> Maintenir une glycémie stable évite les pics de cortisol
                        </p>
                        <ul className="text-sm text-yellow-700 space-y-1">
                          <li>• Privilégier les glucides complexes (quinoa, avoine, légumineuses)</li>
                          <li>• Associer protéines et fibres à chaque repas</li>
                          <li>• Éviter les sucres raffinés et les édulcorants artificiels</li>
                          <li>• Adopter une fréquence de 3 repas + 2 collations saines</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Section 2: Plan Nutritionnel */}
            <div className="mb-8">
              <button
                onClick={() => toggleSection('plan')}
                className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <div className="flex items-center">
                  <i className="ri-calendar-line text-emerald-600 text-xl mr-3"></i>
                  <h3 className="text-xl font-semibold text-gray-800">2. Plan nutritionnel hebdomadaire anti-stress</h3>
                </div>
                <i className={`ri-arrow-${expandedSection === 'plan' ? 'up' : 'down'}-line text-gray-500`}></i>
              </button>
              
              {expandedSection === 'plan' && (
                <div className="mt-4 p-6 bg-white border border-gray-100 rounded-lg">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-4">🌅 Petit-déjeuner énergisant</h4>
                      <div className="space-y-3">
                        <div className="bg-emerald-50 p-3 rounded-lg">
                          <h5 className="font-medium text-emerald-800">Bowl avocat-œuf</h5>
                          <p className="text-sm text-emerald-700">Avocat + œuf poché + graines de tournesol + épinards</p>
                        </div>
                        <div className="bg-blue-50 p-3 rounded-lg">
                          <h5 className="font-medium text-blue-800">Porridge protéiné</h5>
                          <p className="text-sm text-blue-700">Avoine + beurre d'amande + baies + graines de chia</p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-800 mb-4">🥗 Déjeuner équilibré</h4>
                      <div className="space-y-3">
                        <div className="bg-green-50 p-3 rounded-lg">
                          <h5 className="font-medium text-green-800">Salade quinoa-saumon</h5>
                          <p className="text-sm text-green-700">Quinoa + saumon + légumes verts + huile d'olive</p>
                        </div>
                        <div className="bg-orange-50 p-3 rounded-lg">
                          <h5 className="font-medium text-orange-800">Bowl méditerranéen</h5>
                          <p className="text-sm text-orange-700">Légumineuses + légumes grillés + tahini</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 p-4 bg-emerald-100 rounded-lg">
                    <h4 className="font-semibold text-emerald-800 mb-2">💧 Hydratation optimale</h4>
                    <ul className="text-sm text-emerald-700 space-y-1">
                      <li>• 2-3L d'eau pure par jour</li>
                      <li>• Thé vert ou blanc (riche en L-théanine apaisante)</li>
                      <li>• Infusions de camomille, mélisse ou passifloreLimitez café après 14h</li>
                      <li>• Évitez l'alcool qui perturbe le sommeil</li>
                    </ul>
                  </div>
                </div>
              )}
            </div>

            {/* Section 3: Sommeil */}
            <div className="mb-8">
              <button
                onClick={() => toggleSection('sommeil')}
                className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <div className="flex items-center">
                  <i className="ri-moon-line text-emerald-600 text-xl mr-3"></i>
                  <h3 className="text-xl font-semibold text-gray-800">3. Optimisation du sommeil réparateur</h3>
                </div>
                <i className={`ri-arrow-${expandedSection === 'sommeil' ? 'up' : 'down'}-line text-gray-500`}></i>
              </button>
              
              {expandedSection === 'sommeil' && (
                <div className="mt-4 p-6 bg-white border border-gray-100 rounded-lg">
                  <div className="space-y-6">
                    <div className="bg-indigo-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-indigo-800 mb-3">🧬 Science du sommeil et stress</h4>
                      <p className="text-indigo-700 text-sm mb-3">
                        Le sommeil de qualité réduit le cortisol de 23% et améliore la régulation émotionnelle de 60%. 
                        Pendant le sommeil profond, le cerveau évacue les toxines et consolide la mémoire émotionnelle.
                      </p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-semibold text-gray-800 mb-3">🌙 Routine du soir</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center p-2 bg-purple-50 rounded">
                            <span className="text-purple-600 font-medium w-16">21h00</span>
                            <span className="text-purple-700">Arrêt des écrans</span>
                          </div>
                          <div className="flex items-center p-2 bg-blue-50 rounded">
                            <span className="text-blue-600 font-medium w-16">21h30</span>
                            <span className="text-blue-700">Lecture ou méditation</span>
                          </div>
                          <div className="flex items-center p-2 bg-indigo-50 rounded">
                            <span className="text-indigo-600 font-medium w-16">22h00</span>
                            <span className="text-indigo-700">Tisane relaxante</span>
                          </div>
                          <div className="flex items-center p-2 bg-gray-50 rounded">
                            <span className="text-gray-600 font-medium w-16">22h30</span>
                            <span className="text-gray-700">Coucher régulier</span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold text-gray-800 mb-3">🛏️ Environnement optimal</h4>
                        <ul className="text-sm text-gray-700 space-y-2">
                          <li className="flex items-center">
                            <i className="ri-temp-cold-line text-blue-500 mr-2"></i>
                            Température: 18-20°C
                          </li>
                          <li className="flex items-center">
                            <i className="ri-contrast-2-line text-gray-500 mr-2"></i>
                            Obscurité complète
                          </li>
                          <li className="flex items-center">
                            <i className="ri-volume-mute-line text-green-500 mr-2"></i>
                            Silence ou bruits blancs
                          </li>
                          <li className="flex items-center">
                            <i className="ri-smartphone-line text-red-500 mr-2"></i>
                            Pas d'écrans 1h avant coucher
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Section 4: Exercice */}
            <div className="mb-8">
              <button
                onClick={() => toggleSection('exercice')}
                className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <div className="flex items-center">
                  <i className="ri-run-line text-emerald-600 text-xl mr-3"></i>
                  <h3 className="text-xl font-semibold text-gray-800">4. Activité physique et régulation du stress</h3>
                </div>
                <i className={`ri-arrow-${expandedSection === 'exercice' ? 'up' : 'down'}-line text-gray-500`}></i>
              </button>
              
              {expandedSection === 'exercice' && (
                <div className="mt-4 p-6 bg-white border border-gray-100 rounded-lg">
                  <div className="space-y-6">
                    <div className="bg-green-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-green-800 mb-2">💪 Impact physiologique</h4>
                      <p className="text-green-700 text-sm">
                        L'exercice régulier réduit le cortisol chronique, augmente la production d'endorphines 
                        et améliore la neuroplasticité. Même 20 minutes d'activité modérée suffisent à déclencher ces bénéfices.
                      </p>
                    </div>

                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <i className="ri-walk-line text-blue-600 text-3xl mb-2"></i>
                        <h5 className="font-semibold text-blue-800 mb-2">Marche active</h5>
                        <p className="text-sm text-blue-700">30 min/jour</p>
                        <p className="text-xs text-blue-600">Réduit l'anxiété de 20%</p>
                      </div>
                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <i className="ri-heart-pulse-line text-purple-600 text-3xl mb-2"></i>
                        <h5 className="font-semibold text-purple-800 mb-2">Cardio modéré</h5>
                        <p className="text-sm text-purple-700">3x20 min/semaine</p>
                        <p className="text-xs text-purple-600">Booste les endorphines</p>
                      </div>
                      <div className="text-center p-4 bg-orange-50 rounded-lg">
                        <i className="ri-scales-3-line text-orange-600 text-3xl mb-2"></i>
                        <h5 className="font-semibold text-orange-800 mb-2">Yoga/Étirements</h5>
                        <p className="text-sm text-orange-700">15 min quotidien</p>
                        <p className="text-xs text-orange-600">Améliore la flexibilité mentale</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Exercices Pratiques */}
            <div className="bg-emerald-50 rounded-lg p-6 mb-8">
              <h3 className="text-xl font-bold text-emerald-800 mb-4 flex items-center">
                <i className="ri-checkbox-circle-line mr-3"></i>
                Exercices pratiques
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <button
                    onClick={() => toggleExercise('nutrition-journal')}
                    className={`mt-1 w-5 h-5 rounded border-2 flex-shrink-0 flex items-center justify-center ${
                      completedExercises.includes('nutrition-journal')
                        ? 'bg-emerald-500 border-emerald-500 text-white'
                        : 'border-emerald-300 hover:border-emerald-500'
                    } transition-colors`}
                  >
                    {completedExercises.includes('nutrition-journal') && (
                      <i className="ri-check-line text-xs"></i>
                    )}
                  </button>
                  <div>
                    <h4 className="font-semibold text-emerald-800">Journal alimentaire et humeur</h4>
                    <p className="text-sm text-emerald-700 mt-1">
                      Notez pendant 7 jours vos repas et votre niveau de stress. Identifiez les corrélations entre 
                      certains aliments et votre état émotionnel.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <button
                    onClick={() => toggleExercise('sleep-audit')}
                    className={`mt-1 w-5 h-5 rounded border-2 flex-shrink-0 flex items-center justify-center ${
                      completedExercises.includes('sleep-audit')
                        ? 'bg-emerald-500 border-emerald-500 text-white'
                        : 'border-emerald-300 hover:border-emerald-500'
                    } transition-colors`}
                  >
                    {completedExercises.includes('sleep-audit') && (
                      <i className="ri-check-line text-xs"></i>
                    )}
                  </button>
                  <div>
                    <h4 className="font-semibold text-emerald-800">Audit de votre environnement de sommeil</h4>
                    <p className="text-sm text-emerald-700 mt-1">
                      Évaluez votre chambre selon les critères optimaux et apportez 3 améliorations cette semaine.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <button
                    onClick={() => toggleExercise('movement-routine')}
                    className={`mt-1 w-5 h-5 rounded border-2 flex-shrink-0 flex items-center justify-center ${
                      completedExercises.includes('movement-routine')
                        ? 'bg-emerald-500 border-emerald-500 text-white'
                        : 'border-emerald-300 hover:border-emerald-500'
                    } transition-colors`}
                  >
                    {completedExercises.includes('movement-routine') && (
                      <i className="ri-check-line text-xs"></i>
                    )}
                  </button>
                  <div>
                    <h4 className="font-semibold text-emerald-800">Routine de mouvement quotidienne</h4>
                    <p className="text-sm text-emerald-700 mt-1">
                      Choisissez et testez pendant 2 semaines une activité physique de 20 minutes qui vous convient.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Points clés à retenir */}
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <i className="ri-lightbulb-line mr-3"></i>
                Points clés à retenir
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-start">
                    <i className="ri-arrow-right-s-line text-emerald-500 mt-0.5 mr-2 flex-shrink-0"></i>
                    La nutrition influence directement la production de neurotransmetteurs
                  </li>
                  <li className="flex items-start">
                    <i className="ri-arrow-right-s-line text-emerald-500 mt-0.5 mr-2 flex-shrink-0"></i>
                    Un sommeil de qualité réduit significativement le cortisol
                  </li>
                  <li className="flex items-start">
                    <i className="ri-arrow-right-s-line text-emerald-500 mt-0.5 mr-2 flex-shrink-0"></i>
                    L'exercice régulier améliore la résilience au stress à long terme
                  </li>
                </ul>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-start">
                    <i className="ri-arrow-right-s-line text-emerald-500 mt-0.5 mr-2 flex-shrink-0"></i>
                    L'équilibre glycémique prévient les pics de stress
                  </li>
                  <li className="flex items-start">
                    <i className="ri-arrow-right-s-line text-emerald-500 mt-0.5 mr-2 flex-shrink-0"></i>
                    Une routine soir-matin structure favorise la régulation émotionnelle
                  </li>
                  <li className="flex items-start">
                    <i className="ri-arrow-right-s-line text-emerald-500 mt-0.5 mr-2 flex-shrink-0"></i>
                    Même de petits changements ont un impact mesurable
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center mt-8">
          <Link href="/chapitre-2" className="flex items-center text-emerald-600 hover:text-emerald-700 transition-colors cursor-pointer">
            <i className="ri-arrow-left-line mr-2"></i>
            Chapitre précédent
          </Link>
          <Link href="/table-des-matieres" className="text-gray-500 hover:text-gray-700 transition-colors cursor-pointer">
            Table des matières
          </Link>
          <Link href="/chapitre-4" className="flex items-center text-emerald-600 hover:text-emerald-700 transition-colors cursor-pointer">
            Chapitre suivant
            <i className="ri-arrow-right-line ml-2"></i>
          </Link>
        </div>
      </div>
    </div>
  );
}