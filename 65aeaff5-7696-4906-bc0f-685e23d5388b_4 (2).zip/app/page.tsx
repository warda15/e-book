
'use client';

import Link from 'next/link';
import PWAInstallPrompt from '../components/PWAInstallPrompt';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Hero Section */}
      <div className="relative min-h-screen flex items-center justify-center px-4">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=serene%20meditation%20garden%20with%20soft%20morning%20light%2C%20peaceful%20zen%20atmosphere%2C%20minimalist%20design%20with%20natural%20elements%2C%20calming%20blue%20and%20green%20tones%2C%20professional%20wellness%20photography%2C%20high%20quality%2C%20tranquil%20setting%20with%20flowing%20water%20and%20gentle%20mist&width=1920&height=1080&seq=hero-stress-management&orientation=landscape')`
          }}
        >
          <div className="absolute inset-0 bg-white/40"></div>
        </div>
        
        <div className="relative z-10 text-center max-w-4xl mx-auto">
          <div className="mb-4 flex justify-center">
            <div className="bg-indigo-100 text-indigo-800 px-4 py-2 rounded-full text-sm font-medium flex items-center space-x-2">
              <i className="ri-smartphone-line text-indigo-600"></i>
              <span>Disponible hors-ligne • Installation possible</span>
            </div>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold text-gray-800 mb-6 leading-tight">
            Techniques Avancées de
            <span className="text-indigo-600 block mt-2">Gestion du Stress</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-700 mb-8 max-w-3xl mx-auto">
            Allier neurosciences, pleine conscience et nutrition pour une résilience durable
          </p>
          <p className="text-lg text-gray-600 mb-12 max-w-2xl mx-auto">
            Approches modernes pour une santé mentale renforcée face au stress quotidien
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link href="/table-des-matieres" className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
              Commencer la lecture
            </Link>
            <Link href="/introduction" className="bg-white/80 hover:bg-white text-indigo-600 px-8 py-4 rounded-lg text-lg font-semibold transition-colors border border-indigo-200 whitespace-nowrap cursor-pointer">
              Aperçu gratuit
            </Link>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-16">
            Ce que vous découvrirez
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6 rounded-xl bg-blue-50 hover:bg-blue-100 transition-colors">
              <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-brain-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Neurosciences Appliquées</h3>
              <p className="text-gray-600">Comprenez les mécanismes cérébraux du stress et utilisez cette science pour votre bien-être</p>
            </div>
            
            <div className="text-center p-6 rounded-xl bg-green-50 hover:bg-green-100 transition-colors">
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-leaf-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Pleine Conscience Avancée</h3>
              <p className="text-gray-600">Techniques de méditation et mindfulness adaptées à votre rythme de vie moderne</p>
            </div>
            
            <div className="text-center p-6 rounded-xl bg-orange-50 hover:bg-orange-100 transition-colors">
              <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-restaurant-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Nutrition Stratégique</h3>
              <p className="text-gray-600">Alimentation anti-stress et habitudes de vie pour renforcer votre résilience mentale</p>
            </div>
          </div>
        </div>
      </div>

      {/* PWA Benefits Section */}
      <div className="py-20 bg-gradient-to-r from-indigo-50 to-blue-50">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">
            Emportez votre ebook partout
          </h2>
          
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="ri-wifi-off-line text-green-600 text-xl"></i>
              </div>
              <h4 className="font-semibold text-gray-800 mb-2">Lecture hors-ligne</h4>
              <p className="text-sm text-gray-600">Accédez à tout le contenu même sans connexion internet</p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="ri-smartphone-line text-blue-600 text-xl"></i>
              </div>
              <h4 className="font-semibold text-gray-800 mb-2">Installation sur mobile</h4>
              <p className="text-sm text-gray-600">Installez comme une vraie application sur votre téléphone</p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="ri-bookmark-line text-purple-600 text-xl"></i>
              </div>
              <h4 className="font-semibold text-gray-800 mb-2">Synchronisation</h4>
              <p className="text-sm text-gray-600">Vos marque-pages et progression sauvegardés automatiquement</p>
            </div>
          </div>
        </div>
      </div>

      {/* Benefits Section */}
      <div className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-8">
            Transformez votre relation au stress
          </h2>
          
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div className="flex items-start space-x-4 text-left">
              <div className="w-8 h-8 bg-indigo-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <i className="ri-check-line text-white text-sm"></i>
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">Exemples concrets et études de cas</h4>
                <p className="text-gray-600">Applications pratiques validées scientifiquement</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4 text-left">
              <div className="w-8 h-8 bg-indigo-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <i className="ri-check-line text-white text-sm"></i>
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">Exercices pratiques intégrés</h4>
                <p className="text-gray-600">Outils immédiatement applicables au quotidien</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4 text-left">
              <div className="w-8 h-8 bg-indigo-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <i className="ri-check-line text-white text-sm"></i>
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">Plan d'action personnalisé</h4>
                <p className="text-gray-600">Stratégie adaptée à votre profil et vos besoins</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4 text-left">
              <div className="w-8 h-8 bg-indigo-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <i className="ri-check-line text-white text-sm"></i>
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">Ressources complémentaires</h4>
                <p className="text-gray-600">Fiches pratiques, journaux de suivi et checklists</p>
              </div>
            </div>
          </div>
          
          <Link href="/table-des-matieres" className="bg-indigo-600 hover:bg-indigo-700 text-white px-10 py-4 rounded-lg text-lg font-semibold transition-colors whitespace-nowrap cursor-pointer inline-block">
            Accéder au contenu complet
          </Link>
        </div>
      </div>
      
      <PWAInstallPrompt />
    </div>
  );
}
