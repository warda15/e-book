'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Chapitre4() {
  const [currentStep, setCurrentStep] = useState(1);
  const [personalPlan, setPersonalPlan] = useState({
    stressLevel: '',
    mainTriggers: [],
    preferredTechniques: [],
    schedule: '',
    goals: ''
  });
  const [completedExercises, setCompletedExercises] = useState<string[]>([]);

  const toggleExercise = (exerciseId: string) => {
    setCompletedExercises(prev => 
      prev.includes(exerciseId) 
        ? prev.filter(id => id !== exerciseId)
        : [...prev, exerciseId]
    );
  };

  const handleStressLevelChange = (level: string) => {
    setPersonalPlan(prev => ({ ...prev, stressLevel: level }));
  };

  const toggleTrigger = (trigger: string) => {
    setPersonalPlan(prev => ({
      ...prev,
      mainTriggers: prev.mainTriggers.includes(trigger)
        ? prev.mainTriggers.filter(t => t !== trigger)
        : [...prev.mainTriggers, trigger]
    }));
  };

  const toggleTechnique = (technique: string) => {
    setPersonalPlan(prev => ({
      ...prev,
      preferredTechniques: prev.preferredTechniques.includes(technique)
        ? prev.preferredTechniques.filter(t => t !== technique)
        : [...prev.preferredTechniques, technique]
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100">
      {/* Header Navigation */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-purple-600 cursor-pointer">
              <span className="font-['Pacifico']">StressWell</span>
            </Link>
            <div className="flex items-center space-x-6">
              <Link href="/table-des-matieres" className="text-gray-600 hover:text-purple-600 transition-colors cursor-pointer">Table des matières</Link>
              <Link href="/outils-pratiques" className="text-gray-600 hover:text-purple-600 transition-colors cursor-pointer">Outils</Link>
              <Link href="/ressources" className="text-gray-600 hover:text-purple-600 transition-colors cursor-pointer">Ressources</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Chapter Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center bg-purple-100 text-purple-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <i className="ri-compass-3-line mr-2"></i>
            Chapitre 4
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            Stratégie personnelle de résilience
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Intégrez tous les apprentissages en créant votre plan d'action personnalisé pour une résilience durable au stress
          </p>
          <div className="flex items-center justify-center mt-4 text-sm text-gray-500">
            <i className="ri-time-line mr-1"></i>
            <span>12 minutes de lecture</span>
            <span className="mx-2">•</span>
            <i className="ri-bookmark-line mr-1"></i>
            <span>Plan personnalisé inclus</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="bg-white rounded-lg p-4 mb-8 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Progression du chapitre</span>
            <span className="text-sm text-purple-600">100% complété</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-purple-500 h-2 rounded-full" style={{width: '100%'}}></div>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          
          {/* Introduction */}
          <div className="p-8">
            <div className="bg-purple-50 rounded-lg p-6 mb-8">
              <h2 className="text-2xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-target-line mr-3"></i>
                Votre feuille de route personnalisée
              </h2>
              <p className="text-purple-700 leading-relaxed">
                Vous avez exploré les neurosciences du stress, maîtrisé des techniques de mindfulness et découvert 
                l'impact de votre mode de vie. Il est maintenant temps de synthétiser ces connaissances en un plan 
                d'action adapté à votre situation unique.
              </p>
            </div>

            {/* Étape 1: Auto-évaluation */}
            <div className="mb-8">
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white p-4 rounded-t-lg">
                <h3 className="text-xl font-semibold flex items-center">
                  <i className="ri-user-search-line mr-3"></i>
                  Étape 1: Auto-évaluation approfondie
                </h3>
              </div>
              <div className="bg-white border border-gray-200 rounded-b-lg p-6">
                <div className="space-y-6">
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-3">🎯 Évaluation de votre niveau de stress actuel</h4>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                      {['Très faible', 'Faible', 'Modéré', 'Élevé', 'Très élevé'].map((level, index) => (
                        <button
                          key={level}
                          onClick={() => handleStressLevelChange(level)}
                          className={`p-3 text-center rounded-lg border-2 transition-colors ${
                            personalPlan.stressLevel === level
                              ? 'border-purple-500 bg-purple-50 text-purple-700'
                              : 'border-gray-200 hover:border-purple-300 text-gray-600'
                          }`}
                        >
                          <div className="text-sm font-medium">{level}</div>
                          <div className="text-xs mt-1">{index + 1}/5</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-800 mb-3">⚡ Vos principaux déclencheurs de stress</h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {[
                        'Travail/Performance',
                        'Relations sociales',
                        'Santé',
                        'Finances',
                        'Famille',
                        'Changements',
                        'Temps/Planification',
                        'Perfectionnisme',
                        'Conflits'
                      ].map(trigger => (
                        <button
                          key={trigger}
                          onClick={() => toggleTrigger(trigger)}
                          className={`p-2 text-sm rounded-lg border transition-colors ${
                            personalPlan.mainTriggers.includes(trigger)
                              ? 'border-purple-500 bg-purple-50 text-purple-700'
                              : 'border-gray-200 hover:border-purple-300 text-gray-600'
                          }`}
                        >
                          {trigger}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-800 mb-3">🎨 Techniques qui vous attirent le plus</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {[
                        'Méditation de pleine conscience',
                        'Respiration profonde',
                        'Exercice physique',
                        'Journaling',
                        'Visualization',
                        'Yoga',
                        'Marche en nature',
                        'Musique/Art-thérapie'
                      ].map(technique => (
                        <button
                          key={technique}
                          onClick={() => toggleTechnique(technique)}
                          className={`p-2 text-sm rounded-lg border transition-colors ${
                            personalPlan.preferredTechniques.includes(technique)
                              ? 'border-purple-500 bg-purple-50 text-purple-700'
                              : 'border-gray-200 hover:border-purple-300 text-gray-600'
                          }`}
                        >
                          {technique}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Étape 2: Plan Intégré */}
            <div className="mb-8">
              <div className="bg-gradient-to-r from-pink-500 to-orange-500 text-white p-4 rounded-t-lg">
                <h3 className="text-xl font-semibold flex items-center">
                  <i className="ri-roadmap-line mr-3"></i>
                  Étape 2: Votre plan intégré 360°
                </h3>
              </div>
              <div className="bg-white border border-gray-200 rounded-b-lg p-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-4 flex items-center">
                      <i className="ri-brain-line text-purple-600 mr-2"></i>
                      Dimension mentale
                    </h4>
                    <div className="space-y-3">
                      <div className="bg-purple-50 p-3 rounded-lg">
                        <h5 className="font-medium text-purple-800 mb-1">Pratique quotidienne</h5>
                        <p className="text-sm text-purple-700">10 min de méditation matinale + 5 min de respiration consciente</p>
                      </div>
                      <div className="bg-indigo-50 p-3 rounded-lg">
                        <h5 className="font-medium text-indigo-800 mb-1">Techniques d'urgence</h5>
                        <p className="text-sm text-indigo-700">Respiration 4-7-8 + technique STOP + recentrage sensoriel</p>
                      </div>
                      <div className="bg-blue-50 p-3 rounded-lg">
                        <h5 className="font-medium text-blue-800 mb-1">Développement</h5>
                        <p className="text-sm text-blue-700">Journal de gratitude + identification des pensées automatiques</p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-800 mb-4 flex items-center">
                      <i className="ri-heart-pulse-line text-green-600 mr-2"></i>
                      Dimension physique
                    </h4>
                    <div className="space-y-3">
                      <div className="bg-green-50 p-3 rounded-lg">
                        <h5 className="font-medium text-green-800 mb-1">Mouvement</h5>
                        <p className="text-sm text-green-700">30 min de marche active + 2x étirements de 10 min</p>
                      </div>
                      <div className="bg-emerald-50 p-3 rounded-lg">
                        <h5 className="font-medium text-emerald-800 mb-1">Nutrition</h5>
                        <p className="text-sm text-emerald-700">Petit-déjeuner protéiné + collations équilibrées + hydratation</p>
                      </div>
                      <div className="bg-teal-50 p-3 rounded-lg">
                        <h5 className="font-medium text-teal-800 mb-1">Récupération</h5>
                        <p className="text-sm text-teal-700">Coucher régulier 22h30 + rituel de détente + environnement optimal</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-gradient-to-r from-purple-100 to-pink-100 rounded-lg">
                  <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                    <i className="ri-calendar-check-line text-purple-600 mr-2"></i>
                    Planning hebdomadaire type
                  </h4>
                  <div className="grid grid-cols-7 gap-2 text-xs">
                    {['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map((day, index) => (
                      <div key={day} className="text-center">
                        <div className="font-medium text-gray-700 mb-1">{day}</div>
                        <div className="space-y-1">
                          <div className="bg-purple-200 text-purple-800 p-1 rounded">Méditation</div>
                          {index % 2 === 0 && <div className="bg-green-200 text-green-800 p-1 rounded">Sport</div>}
                          {index === 6 && <div className="bg-blue-200 text-blue-800 p-1 rounded">Bilan</div>}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Étape 3: Mesure et Ajustement */}
            <div className="mb-8">
              <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-4 rounded-t-lg">
                <h3 className="text-xl font-semibold flex items-center">
                  <i className="ri-line-chart-line mr-3"></i>
                  Étape 3: Suivi et ajustement continu
                </h3>
              </div>
              <div className="bg-white border border-gray-200 rounded-b-lg p-6">
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                      <i className="ri-calendar-event-line text-orange-600 text-2xl"></i>
                    </div>
                    <h4 className="font-semibold text-gray-800 mb-2">Suivi quotidien</h4>
                    <p className="text-sm text-gray-600">
                      Notez votre niveau de stress (1-10), les techniques utilisées et leur efficacité
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                      <i className="ri-refresh-line text-red-600 text-2xl"></i>
                    </div>
                    <h4 className="font-semibold text-gray-800 mb-2">Bilan hebdomadaire</h4>
                    <p className="text-sm text-gray-600">
                      Analysez les patterns, identifiez ce qui fonctionne et ajustez votre approche
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="bg-pink-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                      <i className="ri-trophy-line text-pink-600 text-2xl"></i>
                    </div>
                    <h4 className="font-semibold text-gray-800 mb-2">Célébration</h4>
                    <p className="text-sm text-gray-600">
                      Reconnaissez vos progrès et récompensez-vous pour votre engagement
                    </p>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-yellow-50 border-l-4 border-yellow-400">
                  <h4 className="font-semibold text-yellow-800 mb-2">💡 Indicateurs de réussite</h4>
                  <ul className="text-sm text-yellow-700 space-y-1">
                    <li>• Diminution du niveau de stress perçu sur 4 semaines</li>
                    <li>• Amélioration de la qualité du sommeil</li>
                    <li>• Récupération plus rapide après les événements stressants</li>
                    <li>• Augmentation de la confiance en vos capacités d'adaptation</li>
                    <li>• Plus grande stabilité émotionnelle au quotidien</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Kit de démarrage */}
            <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg p-6 mb-8">
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <i className="ri-rocket-line mr-3"></i>
                Votre kit de démarrage immédiat
              </h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-3">🚀 Cette semaine, je m'engage à:</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center">
                      <i className="ri-check-line mr-2 text-green-300"></i>
                      Pratiquer 5 minutes de respiration consciente chaque matin
                    </li>
                    <li className="flex items-center">
                      <i className="ri-check-line mr-2 text-green-300"></i>
                      Identifier mes 3 principaux déclencheurs de stress
                    </li>
                    <li className="flex items-center">
                      <i className="ri-check-line mr-2 text-green-300"></i>
                      Tester 2 techniques d'urgence en situation réelle
                    </li>
                    <li className="flex items-center">
                      <i className="ri-check-line mr-2 text-green-300"></i>
                      Optimiser mon environnement de sommeil
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-3">📱 Rappels et supports:</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center">
                      <i className="ri-alarm-line mr-2 text-yellow-300"></i>
                      Programmer 3 alarmes "pause respiration" par jour
                    </li>
                    <li className="flex items-center">
                      <i className="ri-book-open-line mr-2 text-blue-300"></i>
                      Imprimer la fiche technique d'urgence
                    </li>
                    <li className="flex items-center">
                      <i className="ri-group-line mr-2 text-pink-300"></i>
                      Partager mes objectifs avec un proche de confiance
                    </li>
                    <li className="flex items-center">
                      <i className="ri-calendar-line mr-2 text-purple-300"></i>
                      Planifier ma première séance de bilan dans 7 jours
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Exercices Pratiques */}
            <div className="bg-purple-50 rounded-lg p-6 mb-8">
              <h3 className="text-xl font-bold text-purple-800 mb-4 flex items-center">
                <i className="ri-checkbox-circle-line mr-3"></i>
                Exercices de mise en pratique
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <button
                    onClick={() => toggleExercise('personal-contract')}
                    className={`mt-1 w-5 h-5 rounded border-2 flex-shrink-0 flex items-center justify-center ${
                      completedExercises.includes('personal-contract')
                        ? 'bg-purple-500 border-purple-500 text-white'
                        : 'border-purple-300 hover:border-purple-500'
                    } transition-colors`}
                  >
                    {completedExercises.includes('personal-contract') && (
                      <i className="ri-check-line text-xs"></i>
                    )}
                  </button>
                  <div>
                    <h4 className="font-semibold text-purple-800">Rédigez votre contrat personnel</h4>
                    <p className="text-sm text-purple-700 mt-1">
                      Formalisez vos engagements en écrivant un contrat avec vous-même. Définissez vos objectifs, 
                      vos moyens d'action et votre système de récompenses.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <button
                    onClick={() => toggleExercise('emergency-plan')}
                    className={`mt-1 w-5 h-5 rounded border-2 flex-shrink-0 flex items-center justify-center ${
                      completedExercises.includes('emergency-plan')
                        ? 'bg-purple-500 border-purple-500 text-white'
                        : 'border-purple-300 hover:border-purple-500'
                    } transition-colors`}
                  >
                    {completedExercises.includes('emergency-plan') && (
                      <i className="ri-check-line text-xs"></i>
                    )}
                  </button>
                  <div>
                    <h4 className="font-semibold text-purple-800">Créez votre plan d'urgence anti-stress</h4>
                    <p className="text-sm text-purple-700 mt-1">
                      Préparez une fiche d'action rapide avec 5 techniques à utiliser en cas de stress intense. 
                      Gardez-la accessible (téléphone, bureau, sac).
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <button
                    onClick={() => toggleExercise('support-network')}
                    className={`mt-1 w-5 h-5 rounded border-2 flex-shrink-0 flex items-center justify-center ${
                      completedExercises.includes('support-network')
                        ? 'bg-purple-500 border-purple-500 text-white'
                        : 'border-purple-300 hover:border-purple-500'
                    } transition-colors`}
                  >
                    {completedExercises.includes('support-network') && (
                      <i className="ri-check-line text-xs"></i>
                    )}
                  </button>
                  <div>
                    <h4 className="font-semibold text-purple-800">Activez votre réseau de soutien</h4>
                    <p className="text-sm text-purple-700 mt-1">
                      Identifiez 3 personnes qui peuvent vous accompagner dans cette démarche. Partagez avec elles 
                      vos objectifs et demandez leur soutien bienveillant.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Message de conclusion */}
            <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white rounded-lg p-8 text-center">
              <i className="ri-award-line text-4xl mb-4"></i>
              <h3 className="text-2xl font-bold mb-4">Félicitations ! Vous avez terminé votre parcours</h3>
              <p className="text-lg mb-6">
                Vous possédez maintenant tous les outils pour développer une résilience authentique au stress. 
                Le plus important n'est pas la perfection, mais la constance dans la pratique.
              </p>
              <div className="bg-white/20 rounded-lg p-4 text-center">
                <p className="italic text-lg">
                  "La résilience ne consiste pas à éviter la tempête, mais à apprendre à danser sous la pluie."
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center mt-8">
          <Link href="/chapitre-3" className="flex items-center text-purple-600 hover:text-purple-700 transition-colors cursor-pointer">
            <i className="ri-arrow-left-line mr-2"></i>
            Chapitre précédent
          </Link>
          <Link href="/table-des-matieres" className="text-gray-500 hover:text-gray-700 transition-colors cursor-pointer">
            Table des matières
          </Link>
          <Link href="/conclusion" className="flex items-center text-purple-600 hover:text-purple-700 transition-colors cursor-pointer">
            Conclusion
            <i className="ri-arrow-right-line ml-2"></i>
          </Link>
        </div>
      </div>
    </div>
  );
}