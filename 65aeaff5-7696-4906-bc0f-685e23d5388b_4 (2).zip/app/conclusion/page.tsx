'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Conclusion() {
  const [reflection, setReflection] = useState('');
  const [commitments, setCommitments] = useState<string[]>([]);

  const toggleCommitment = (commitment: string) => {
    setCommitments(prev => 
      prev.includes(commitment) 
        ? prev.filter(c => c !== commitment)
        : [...prev, commitment]
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      {/* Header Navigation */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-indigo-600 cursor-pointer">
              <span className="font-['Pacifico']">StressWell</span>
            </Link>
            <div className="flex items-center space-x-6">
              <Link href="/table-des-matieres" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">Table des matières</Link>
              <Link href="/outils-pratiques" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">Outils</Link>
              <Link href="/ressources" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">Ressources</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center bg-gradient-to-r from-indigo-100 to-purple-100 text-indigo-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <i className="ri-flag-line mr-2"></i>
            Conclusion
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            Votre nouveau départ vers la résilience
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Synthèse de votre parcours et invitation à une pratique durable pour une vie plus sereine et équilibrée
          </p>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-8">
            
            {/* Récapitulatif du parcours */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i className="ri-road-map-line text-indigo-600 mr-3"></i>
                Votre parcours accompli
              </h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="bg-blue-50 p-5 rounded-lg border-l-4 border-blue-400">
                    <h3 className="font-semibold text-blue-800 mb-2 flex items-center">
                      <i className="ri-brain-line mr-2"></i>
                      Chapitre 1: Neurosciences
                    </h3>
                    <p className="text-sm text-blue-700">
                      Vous avez découvert les mécanismes cérébraux du stress et compris pourquoi votre corps réagit comme il le fait. 
                      Cette connaissance vous donne le pouvoir de transformer votre relation au stress.
                    </p>
                  </div>
                  
                  <div className="bg-purple-50 p-5 rounded-lg border-l-4 border-purple-400">
                    <h3 className="font-semibold text-purple-800 mb-2 flex items-center">
                      <i className="ri-heart-line mr-2"></i>
                      Chapitre 2: Mindfulness
                    </h3>
                    <p className="text-sm text-purple-700">
                      Vous maîtrisez maintenant des techniques de pleine conscience qui vous permettent de rester centré 
                      même dans les moments difficiles. La méditation n'est plus un mystère pour vous.
                    </p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="bg-green-50 p-5 rounded-lg border-l-4 border-green-400">
                    <h3 className="font-semibold text-green-800 mb-2 flex items-center">
                      <i className="ri-leaf-line mr-2"></i>
                      Chapitre 3: Mode de vie
                    </h3>
                    <p className="text-sm text-green-700">
                      Vous connaissez l'impact crucial de la nutrition, du sommeil et de l'exercice sur votre résilience. 
                      Votre corps est maintenant votre allié dans la gestion du stress.
                    </p>
                  </div>
                  
                  <div className="bg-pink-50 p-5 rounded-lg border-l-4 border-pink-400">
                    <h3 className="font-semibold text-pink-800 mb-2 flex items-center">
                      <i className="ri-compass-3-line mr-2"></i>
                      Chapitre 4: Stratégie personnelle
                    </h3>
                    <p className="text-sm text-pink-700">
                      Vous avez créé votre plan d'action personnalisé et vous savez comment adapter les techniques 
                      à votre situation unique. Vous êtes maintenant autonome dans votre démarche.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Transformation réalisée */}
            <div className="mb-8 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg p-6">
              <h2 className="text-2xl font-bold mb-4 flex items-center">
                <i className="ri-trophy-line mr-3"></i>
                Votre transformation en chiffres
              </h2>
              
              <div className="grid md:grid-cols-4 gap-4">
                <div className="text-center bg-white/20 rounded-lg p-4">
                  <div className="text-3xl font-bold mb-1">15+</div>
                  <div className="text-sm">Techniques apprises</div>
                </div>
                <div className="text-center bg-white/20 rounded-lg p-4">
                  <div className="text-3xl font-bold mb-1">4</div>
                  <div className="text-sm">Dimensions maîtrisées</div>
                </div>
                <div className="text-center bg-white/20 rounded-lg p-4">
                  <div className="text-3xl font-bold mb-1">50+</div>
                  <div className="text-sm">Exercices pratiques</div>
                </div>
                <div className="text-center bg-white/20 rounded-lg p-4">
                  <div className="text-3xl font-bold mb-1">∞</div>
                  <div className="text-sm">Possibilités d'application</div>
                </div>
              </div>
            </div>

            {/* Principes fondamentaux */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i className="ri-lightbulb-line text-yellow-500 mr-3"></i>
                Les 7 principes fondamentaux à retenir
              </h2>
              
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  {
                    icon: "ri-seedling-line",
                    title: "La pratique régulière prime sur l'intensité",
                    description: "10 minutes quotidiennes valent mieux qu'une heure hebdomadaire",
                    color: "green"
                  },
                  {
                    icon: "ri-heart-pulse-line",
                    title: "Votre corps et votre esprit sont interconnectés",
                    description: "Prendre soin de l'un, c'est prendre soin de l'autre",
                    color: "red"
                  },
                  {
                    icon: "ri-time-line",
                    title: "La patience avec soi-même est essentielle",
                    description: "Le changement durable prend du temps et de la bienveillance",
                    color: "blue"
                  },
                  {
                    icon: "ri-scales-line",
                    title: "L'équilibre est personnel et évolutif",
                    description: "Ce qui fonctionne pour vous peut changer selon les périodes",
                    color: "purple"
                  },
                  {
                    icon: "ri-community-line",
                    title: "Le soutien social renforce la résilience",
                    description: "S'entourer de personnes bienveillantes facilite le parcours",
                    color: "indigo"
                  },
                  {
                    icon: "ri-refresh-line",
                    title: "L'adaptation continue est une force",
                    description: "Savoir ajuster ses stratégies selon les situations",
                    color: "teal"
                  },
                  {
                    icon: "ri-star-line",
                    title: "Célébrer chaque progrès nourrit la motivation",
                    description: "Reconnaître ses victoires, même petites, maintient l'élan",
                    color: "yellow"
                  },
                  {
                    icon: "ri-compass-line",
                    title: "Votre intuition est votre meilleur guide",
                    description: "Écoutez ce que votre corps et votre cœur vous disent",
                    color: "pink"
                  }
                ].map((principle, index) => (
                  <div key={index} className={`bg-${principle.color}-50 p-4 rounded-lg border border-${principle.color}-200`}>
                    <div className="flex items-start space-x-3">
                      <i className={`${principle.icon} text-${principle.color}-600 text-xl mt-1 flex-shrink-0`}></i>
                      <div>
                        <h3 className={`font-semibold text-${principle.color}-800 mb-1`}>{principle.title}</h3>
                        <p className={`text-sm text-${principle.color}-700`}>{principle.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Engagement personnel */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i className="ri-contract-line text-purple-600 mr-3"></i>
                Votre engagement pour les prochains mois
              </h2>
              
              <div className="bg-purple-50 rounded-lg p-6">
                <p className="text-purple-700 mb-4">
                  Choisissez les engagements qui résonnent le plus avec vous pour les 3 prochains mois :
                </p>
                
                <div className="grid md:grid-cols-2 gap-3">
                  {[
                    "Pratiquer 10 minutes de méditation quotidiennement",
                    "Maintenir un journal de gratitude hebdomadaire",
                    "Faire une marche consciente 3 fois par semaine",
                    "Optimiser mon environnement de sommeil",
                    "Pratiquer la respiration profonde dans les moments de stress",
                    "Intégrer des micro-pauses conscientes dans ma journée",
                    "Cultiver une alimentation plus équilibrée",
                    "Développer mon réseau de soutien social",
                    "Célébrer mes progrès chaque semaine",
                    "Continuer à apprendre sur la gestion du stress"
                  ].map(commitment => (
                    <button
                      key={commitment}
                      onClick={() => toggleCommitment(commitment)}
                      className={`text-left p-3 rounded-lg border transition-colors ${
                        commitments.includes(commitment)
                          ? 'border-purple-500 bg-purple-100 text-purple-800'
                          : 'border-purple-200 hover:border-purple-400 text-purple-700'
                      }`}
                    >
                      <div className="flex items-center">
                        <i className={`${commitments.includes(commitment) ? 'ri-checkbox-circle-fill text-purple-600' : 'ri-checkbox-blank-circle-line text-purple-400'} mr-2`}></i>
                        <span className="text-sm">{commitment}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Réflexion personnelle */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i className="ri-quill-pen-line text-indigo-600 mr-3"></i>
                Votre réflexion personnelle
              </h2>
              
              <div className="bg-indigo-50 rounded-lg p-6">
                <label className="block text-indigo-800 font-medium mb-3">
                  Que retenez-vous de plus important de ce parcours ? Comment vous sentez-vous maintenant ?
                </label>
                <textarea
                  value={reflection}
                  onChange={(e) => setReflection(e.target.value)}
                  placeholder="Prenez le temps d'écrire vos réflexions, vos découvertes, vos ressentis... Cette introspection vous aidera à ancrer vos apprentissages."
                  className="w-full h-32 p-4 border border-indigo-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 resize-none"
                />
                <p className="text-sm text-indigo-600 mt-2">
                  {reflection.length}/500 caractères
                </p>
              </div>
            </div>

            {/* Message d'encouragement final */}
            <div className="bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 text-white rounded-lg p-8 text-center">
              <i className="ri-rocket-line text-5xl mb-4"></i>
              <h2 className="text-3xl font-bold mb-4">Vous êtes maintenant prêt(e) !</h2>
              <p className="text-lg mb-6 max-w-2xl mx-auto">
                Ce n'est pas la fin d'un parcours, mais le début d'une nouvelle façon de vivre. 
                Vous avez maintenant tous les outils pour naviguer avec sérénité dans les défis de la vie. 
                Faites-vous confiance, vous avez le pouvoir de créer la vie équilibrée que vous méritez.
              </p>
              
              <div className="bg-white/20 rounded-lg p-6 mb-6">
                <p className="text-xl italic font-medium">
                  "Le stress ne vient pas de ce qui se passe dans votre vie. 
                  Il vient de vos pensées sur ce qui se passe dans votre vie."
                </p>
                <p className="text-sm mt-2 opacity-90">— Andrew Bernstein</p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Link href="/outils-pratiques" className="bg-white text-indigo-600 px-6 py-3 rounded-lg font-semibold hover:bg-indigo-50 transition-colors whitespace-nowrap cursor-pointer">
                  Accéder aux outils pratiques
                </Link>
                <Link href="/ressources" className="bg-transparent border-2 border-white text-white px-6 py-3 rounded-lg font-semibold hover:bg-white/10 transition-colors whitespace-nowrap cursor-pointer">
                  Explorer les ressources
                </Link>
              </div>
            </div>

            {/* Derniers conseils */}
            <div className="mt-8 bg-yellow-50 border border-yellow-200 rounded-lg p-6">
              <h3 className="font-semibold text-yellow-800 mb-3 flex items-center">
                <i className="ri-lightbulb-flash-line mr-2"></i>
                Derniers conseils pour réussir
              </h3>
              <div className="grid md:grid-cols-2 gap-4 text-sm text-yellow-700">
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <i className="ri-arrow-right-s-line text-yellow-600 mt-0.5 mr-1 flex-shrink-0"></i>
                    Commencez petit et construisez progressivement
                  </li>
                  <li className="flex items-start">
                    <i className="ri-arrow-right-s-line text-yellow-600 mt-0.5 mr-1 flex-shrink-0"></i>
                    Soyez patient avec vous-même lors des rechutes
                  </li>
                  <li className="flex items-start">
                    <i className="ri-arrow-right-s-line text-yellow-600 mt-0.5 mr-1 flex-shrink-0"></i>
                    Adaptez les techniques à votre situation unique
                  </li>
                </ul>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <i className="ri-arrow-right-s-line text-yellow-600 mt-0.5 mr-1 flex-shrink-0"></i>
                    Entourez-vous de personnes qui vous soutiennent
                  </li>
                  <li className="flex items-start">
                    <i className="ri-arrow-right-s-line text-yellow-600 mt-0.5 mr-1 flex-shrink-0"></i>
                    Célébrez chaque petit progrès réalisé
                  </li>
                  <li className="flex items-start">
                    <i className="ri-arrow-right-s-line text-yellow-600 mt-0.5 mr-1 flex-shrink-0"></i>
                    Continuez à apprendre et à vous développer
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center mt-8">
          <Link href="/chapitre-4" className="flex items-center text-indigo-600 hover:text-indigo-700 transition-colors cursor-pointer">
            <i className="ri-arrow-left-line mr-2"></i>
            Chapitre précédent
          </Link>
          <Link href="/table-des-matieres" className="text-gray-500 hover:text-gray-700 transition-colors cursor-pointer">
            Table des matières
          </Link>
          <Link href="/bonus" className="flex items-center text-indigo-600 hover:text-indigo-700 transition-colors cursor-pointer">
            Section Bonus
            <i className="ri-arrow-right-line ml-2"></i>
          </Link>
        </div>
      </div>
    </div>
  );
}