'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Chapitre1() {
  const [activeSection, setActiveSection] = useState('mecanismes');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-indigo-600 cursor-pointer">
              <span className="font-['Pacifico']">StressWell</span>
            </Link>
            <div className="flex items-center space-x-6">
              <Link href="/table-des-matieres" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">Table des matières</Link>
              <Link href="/chapitre-2" className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors whitespace-nowrap cursor-pointer">Chapitre suivant</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Chapter Header */}
        <div className="text-center mb-12">
          <div className="inline-block bg-indigo-100 text-indigo-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            Chapitre 1
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Comprendre le stress au niveau neuroscientifique</h1>
          <p className="text-lg text-gray-600">Les mécanismes cérébraux du stress et leur impact sur notre bien-être</p>
        </div>

        {/* Navigation Pills */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          <button
            onClick={() => setActiveSection('mecanismes')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeSection === 'mecanismes' 
                ? 'bg-indigo-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-indigo-50'
            }`}
          >
            Mécanismes cérébraux
          </button>
          <button
            onClick={() => setActiveSection('chronique')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeSection === 'chronique' 
                ? 'bg-indigo-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-indigo-50'
            }`}
          >
            Stress chronique
          </button>
          <button
            onClick={() => setActiveSection('neuroplasticite')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeSection === 'neuroplasticite' 
                ? 'bg-indigo-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-indigo-50'
            }`}
          >
            Neuroplasticité
          </button>
        </div>

        {/* Content Sections */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Section 1: Mécanismes cérébraux */}
          {activeSection === 'mecanismes' && (
            <div className="space-y-6">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-brain-line text-blue-600 text-xl"></i>
                </div>
                <h2 className="text-2xl font-bold text-gray-800">Les mécanismes cérébraux du stress</h2>
              </div>

              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed mb-6">
                  Le stress déclenche une cascade de réactions neurobiologiques complexes impliquant plusieurs structures cérébrales clés. Comprendre ces mécanismes est essentiel pour développer des stratégies efficaces de gestion du stress.
                </p>

                <div className="grid md:grid-cols-2 gap-6 my-8">
                  <div className="bg-blue-50 p-6 rounded-lg border-l-4 border-blue-400">
                    <h4 className="font-semibold text-blue-800 mb-3">L'amygdale</h4>
                    <p className="text-blue-700 text-sm mb-2">Centre de détection des menaces</p>
                    <ul className="text-blue-700 text-sm space-y-1">
                      <li>• Analyse des signaux de danger</li>
                      <li>• Déclenche la réponse fight/flight</li>
                      <li>• Active en 0,1 seconde</li>
                    </ul>
                  </div>
                  <div className="bg-green-50 p-6 rounded-lg border-l-4 border-green-400">
                    <h4 className="font-semibold text-green-800 mb-3">Le cortex préfrontal</h4>
                    <p className="text-green-700 text-sm mb-2">Centre de contrôle exécutif</p>
                    <ul className="text-green-700 text-sm space-y-1">
                      <li>• Évalue rationnellement la situation</li>
                      <li>• Régule les émotions</li>
                      <li>• Planifie les réponses adaptées</li>
                    </ul>
                  </div>
                </div>

                <div className="bg-yellow-50 p-6 rounded-lg my-8">
                  <h3 className="font-semibold text-yellow-800 mb-4">L'axe hypothalamo-hypophyso-surrénalien (HHS)</h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-yellow-200 rounded-full flex items-center justify-center mx-auto mb-2">
                        <span className="text-yellow-800 font-bold">1</span>
                      </div>
                      <h5 className="font-medium text-yellow-800">Hypothalamus</h5>
                      <p className="text-yellow-700 text-sm">Libère CRH</p>
                    </div>
                    <div className="text-center">
                      <div className="w-16 h-16 bg-yellow-200 rounded-full flex items-center justify-center mx-auto mb-2">
                        <span className="text-yellow-800 font-bold">2</span>
                      </div>
                      <h5 className="font-medium text-yellow-800">Hypophyse</h5>
                      <p className="text-yellow-700 text-sm">Sécrète ACTH</p>
                    </div>
                    <div className="text-center">
                      <div className="w-16 h-16 bg-yellow-200 rounded-full flex items-center justify-center mx-auto mb-2">
                        <span className="text-yellow-800 font-bold">3</span>
                      </div>
                      <h5 className="font-medium text-yellow-800">Surrénales</h5>
                      <p className="text-yellow-700 text-sm">Produisent cortisol</p>
                    </div>
                  </div>
                </div>

                <p className="text-gray-700 leading-relaxed">
                  Cette orchestration neurobiologique, parfaitement adaptée aux dangers ponctuels, devient problématique lorsqu'elle s'active de manière chronique face aux stress modernes.
                </p>
              </div>
            </div>
          )}

          {/* Section 2: Impact du stress chronique */}
          {activeSection === 'chronique' && (
            <div className="space-y-6">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-alert-line text-red-600 text-xl"></i>
                </div>
                <h2 className="text-2xl font-bold text-gray-800">L'impact du stress chronique sur le cerveau</h2>
              </div>

              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed mb-6">
                  Le stress chronique modifie profondément la structure et le fonctionnement du cerveau. Ces changements, initialement adaptatifs, deviennent délétères sur le long terme.
                </p>

                <div className="bg-red-50 border-l-4 border-red-400 p-6 my-8">
                  <h3 className="font-semibold text-red-800 mb-4">Conséquences du stress chronique</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium text-red-800 mb-2">Modifications structurelles</h4>
                      <ul className="space-y-1 text-red-700 text-sm">
                        <li>• Atrophie de l'hippocampe</li>
                        <li>• Réduction du cortex préfrontal</li>
                        <li>• Hypertrophie de l'amygdale</li>
                        <li>• Altération de la matière blanche</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium text-red-800 mb-2">Dysfonctionnements</h4>
                      <ul className="space-y-1 text-red-700 text-sm">
                        <li>• Troubles de la mémoire</li>
                        <li>• Difficultés de concentration</li>
                        <li>• Dérégulation émotionnelle</li>
                        <li>• Prise de décision altérée</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-orange-50 p-6 rounded-lg my-8">
                  <h3 className="font-semibold text-orange-800 mb-3">Le cercle vicieux du stress chronique</h3>
                  <div className="flex items-center justify-center">
                    <div className="text-center max-w-2xl">
                      <div className="relative">
                        <img 
                          src="https://readdy.ai/api/search-image?query=circular%20diagram%20showing%20stress%20cycle%20with%20brain%20illustrations%2C%20medical%20scientific%20visualization%2C%20clean%20modern%20design%20with%20arrows%20showing%20progression%2C%20neuroscience%20infographic%20style%2C%20professional%20medical%20illustration%2C%20stress%20response%20pathway%20visualization&width=400&height=300&seq=stress-cycle-brain&orientation=landscape"
                          alt="Cycle du stress chronique"
                          className="w-full rounded-lg object-top"
                        />
                      </div>
                      <p className="text-orange-700 text-sm mt-4">
                        Le stress chronique crée un cercle vicieux : plus nous sommes stressés, moins notre cerveau est capable de gérer efficacement le stress.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 p-6 rounded-lg my-8">
                  <h3 className="font-semibold text-blue-800 mb-3">Marqueurs biologiques du stress chronique</h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="text-center">
                      <i className="ri-drop-line text-blue-600 text-2xl mb-2"></i>
                      <h5 className="font-medium text-blue-800">Cortisol élevé</h5>
                      <p className="text-blue-700 text-sm">Hormone du stress en excès</p>
                    </div>
                    <div className="text-center">
                      <i className="ri-fire-line text-blue-600 text-2xl mb-2"></i>
                      <h5 className="font-medium text-blue-800">Inflammation</h5>
                      <p className="text-blue-700 text-sm">Cytokines pro-inflammatoires</p>
                    </div>
                    <div className="text-center">
                      <i className="ri-dna-line text-blue-600 text-2xl mb-2"></i>
                      <h5 className="font-medium text-blue-800">Stress oxydatif</h5>
                      <p className="text-blue-700 text-sm">Dommages cellulaires</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Section 3: Neuroplasticité et récupération */}
          {activeSection === 'neuroplasticite' && (
            <div className="space-y-6">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-refresh-line text-green-600 text-xl"></i>
                </div>
                <h2 className="text-2xl font-bold text-gray-800">Neuroplasticité et capacité de récupération</h2>
              </div>

              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed mb-6">
                  La neuroplasticité - capacité du cerveau à se remodeler - offre un espoir considérable. Même après des années de stress chronique, le cerveau peut retrouver sa santé et ses capacités optimales.
                </p>

                <div className="bg-green-50 border-l-4 border-green-400 p-6 my-8">
                  <h3 className="font-semibold text-green-800 mb-4">Mécanismes de récupération</h3>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <i className="ri-arrow-up-line text-white text-sm"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-green-800">Neurogenèse</h4>
                        <p className="text-green-700 text-sm">Formation de nouveaux neurones dans l'hippocampe</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <i className="ri-links-line text-white text-sm"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-green-800">Synaptogenèse</h4>
                        <p className="text-green-700 text-sm">Création de nouvelles connexions synaptiques</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <i className="ri-shield-line text-white text-sm"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-green-800">Myélinisation</h4>
                        <p className="text-green-700 text-sm">Renforcement de la gaine de myéline</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6 my-8">
                  <div className="bg-purple-50 p-6 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-3">Facteurs favorisant la neuroplasticité</h4>
                    <ul className="space-y-2 text-purple-700 text-sm">
                      <li>• Méditation et pleine conscience</li>
                      <li>• Exercice physique régulier</li>
                      <li>• Sommeil de qualité</li>
                      <li>• Apprentissage de nouvelles compétences</li>
                      <li>• Relations sociales positives</li>
                      <li>• Nutrition optimale</li>
                    </ul>
                  </div>
                  <div className="bg-orange-50 p-6 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-3">Chronologie de récupération</h4>
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <span className="w-16 text-orange-700 text-sm font-medium">2-4 sem</span>
                        <span className="text-orange-700 text-sm">Premiers changements fonctionnels</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-16 text-orange-700 text-sm font-medium">2-3 mois</span>
                        <span className="text-orange-700 text-sm">Modifications structurelles</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-16 text-orange-700 text-sm font-medium">6-12 mois</span>
                        <span className="text-orange-700 text-sm">Récupération optimale</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-8 rounded-xl my-8 text-center">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Exercice pratique : Visualisation neuroplastique</h3>
                  <p className="text-gray-700 mb-6">
                    Fermez les yeux et visualisez votre cerveau en train de se régénérer. Imaginez de nouvelles connexions neuronales se formant, votre hippocampe se renforçant, et votre cortex préfrontal reprenant le contrôle.
                  </p>
                  <div className="bg-white/80 p-4 rounded-lg inline-block">
                    <p className="text-sm text-gray-600 font-medium">Pratiquez cette visualisation 5 minutes par jour</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="mt-8 flex justify-between items-center">
          <Link href="/introduction" className="flex items-center text-indigo-600 hover:text-indigo-700 transition-colors cursor-pointer">
            <i className="ri-arrow-left-line mr-2"></i>
            Introduction
          </Link>
          <Link href="/chapitre-2" className="flex items-center bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
            Chapitre 2 : Mindfulness
            <i className="ri-arrow-right-line ml-2"></i>
          </Link>
        </div>
      </div>
    </div>
  );
}