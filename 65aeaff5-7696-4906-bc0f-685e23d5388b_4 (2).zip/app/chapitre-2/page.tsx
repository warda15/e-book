'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Chapitre2() {
  const [activeSection, setActiveSection] = useState('principes');

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-indigo-600 cursor-pointer">
              <span className="font-['Pacifico']">StressWell</span>
            </Link>
            <div className="flex items-center space-x-6">
              <Link href="/table-des-matieres" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">Table des matières</Link>
              <Link href="/chapitre-3" className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors whitespace-nowrap cursor-pointer">Chapitre suivant</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Chapter Header */}
        <div className="text-center mb-12">
          <div className="inline-block bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            Chapitre 2
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Mindfulness et méditation avancées</h1>
          <p className="text-lg text-gray-600">Techniques de pleine conscience adaptées au stress moderne</p>
        </div>

        {/* Navigation Pills */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          <button
            onClick={() => setActiveSection('principes')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeSection === 'principes' 
                ? 'bg-green-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-green-50'
            }`}
          >
            Principes de base
          </button>
          <button
            onClick={() => setActiveSection('techniques')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeSection === 'techniques' 
                ? 'bg-green-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-green-50'
            }`}
          >
            Techniques avancées
          </button>
          <button
            onClick={() => setActiveSection('integration')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeSection === 'integration' 
                ? 'bg-green-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-green-50'
            }`}
          >
            Intégration quotidienne
          </button>
        </div>

        {/* Content Sections */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Section 1: Principes */}
          {activeSection === 'principes' && (
            <div className="space-y-6">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-leaf-line text-green-600 text-xl"></i>
                </div>
                <h2 className="text-2xl font-bold text-gray-800">Principes fondamentaux de la pleine conscience</h2>
              </div>

              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed mb-6">
                  La pleine conscience (mindfulness) est la capacité à porter une attention bienveillante au moment présent, sans jugement. Cette pratique millénaire, validée par la science moderne, constitue un outil puissant contre le stress.
                </p>

                <div className="grid md:grid-cols-2 gap-6 my-8">
                  <div className="bg-green-50 p-6 rounded-lg">
                    <img 
                      src="https://readdy.ai/api/search-image?query=peaceful%20meditation%20scene%20with%20person%20sitting%20in%20lotus%20position%2C%20serene%20natural%20environment%2C%20soft%20lighting%2C%20mindfulness%20concept%2C%20zen%20garden%20setting%2C%20calming%20atmosphere%2C%20spiritual%20wellness%20photography&width=300&height=200&seq=meditation-scene&orientation=landscape"
                      alt="Méditation en pleine conscience"
                      className="w-full h-32 object-cover rounded-lg mb-4 object-top"
                    />
                    <h4 className="font-semibold text-green-800 mb-2">Présence attentive</h4>
                    <p className="text-green-700 text-sm">Observer sans se laisser emporter par les pensées</p>
                  </div>
                  <div className="bg-blue-50 p-6 rounded-lg">
                    <img 
                      src="https://readdy.ai/api/search-image?query=gentle%20hands%20in%20acceptance%20gesture%2C%20peaceful%20mindful%20moment%2C%20soft%20natural%20lighting%2C%20non-judgmental%20awareness%20concept%2C%20serene%20contemplative%20atmosphere%2C%20wellness%20and%20self-compassion%20imagery&width=300&height=200&seq=acceptance-gesture&orientation=landscape"
                      alt="Acceptation sans jugement"
                      className="w-full h-32 object-cover rounded-lg mb-4 object-top"
                    />
                    <h4 className="font-semibold text-blue-800 mb-2">Acceptation sans jugement</h4>
                    <p className="text-blue-700 text-sm">Accueillir l'expérience telle qu'elle est</p>
                  </div>
                </div>

                <div className="bg-teal-50 border-l-4 border-teal-400 p-6 my-8">
                  <h3 className="font-semibold text-teal-800 mb-4">Les 7 piliers de la pleine conscience (Jon Kabat-Zinn)</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <div className="w-6 h-6 bg-teal-500 rounded-full flex items-center justify-center mr-3">
                          <span className="text-white text-xs font-bold">1</span>
                        </div>
                        <span className="text-teal-800 font-medium">Non-jugement</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-6 h-6 bg-teal-500 rounded-full flex items-center justify-center mr-3">
                          <span className="text-white text-xs font-bold">2</span>
                        </div>
                        <span className="text-teal-800 font-medium">Patience</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-6 h-6 bg-teal-500 rounded-full flex items-center justify-center mr-3">
                          <span className="text-white text-xs font-bold">3</span>
                        </div>
                        <span className="text-teal-800 font-medium">Esprit du débutant</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-6 h-6 bg-teal-500 rounded-full flex items-center justify-center mr-3">
                          <span className="text-white text-xs font-bold">4</span>
                        </div>
                        <span className="text-teal-800 font-medium">Confiance</span>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <div className="w-6 h-6 bg-teal-500 rounded-full flex items-center justify-center mr-3">
                          <span className="text-white text-xs font-bold">5</span>
                        </div>
                        <span className="text-teal-800 font-medium">Non-effort</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-6 h-6 bg-teal-500 rounded-full flex items-center justify-center mr-3">
                          <span className="text-white text-xs font-bold">6</span>
                        </div>
                        <span className="text-teal-800 font-medium">Acceptation</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-6 h-6 bg-teal-500 rounded-full flex items-center justify-center mr-3">
                          <span className="text-white text-xs font-bold">7</span>
                        </div>
                        <span className="text-teal-800 font-medium">Lâcher-prise</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-50 p-6 rounded-lg my-8">
                  <h3 className="font-semibold text-yellow-800 mb-3">Bienfaits scientifiquement prouvés</h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="text-center">
                      <i className="ri-brain-line text-yellow-600 text-2xl mb-2"></i>
                      <h5 className="font-medium text-yellow-800">Neuroplasticité</h5>
                      <p className="text-yellow-700 text-sm">Renforce les connexions bénéfiques</p>
                    </div>
                    <div className="text-center">
                      <i className="ri-heart-line text-yellow-600 text-2xl mb-2"></i>
                      <h5 className="font-medium text-yellow-800">Régulation émotionnelle</h5>
                      <p className="text-yellow-700 text-sm">Diminue la réactivité</p>
                    </div>
                    <div className="text-center">
                      <i className="ri-shield-line text-yellow-600 text-2xl mb-2"></i>
                      <h5 className="font-medium text-yellow-800">Système immunitaire</h5>
                      <p className="text-yellow-700 text-sm">Renforce les défenses naturelles</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Section 2: Techniques avancées */}
          {activeSection === 'techniques' && (
            <div className="space-y-6">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-focus-3-line text-purple-600 text-xl"></i>
                </div>
                <h2 className="text-2xl font-bold text-gray-800">Techniques de méditation avancées</h2>
              </div>

              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed mb-6">
                  Au-delà de la méditation de base, ces techniques spécialisées ciblent différents aspects du stress et s'adaptent aux contraintes de la vie moderne.
                </p>

                <div className="space-y-8">
                  <div className="bg-blue-50 p-6 rounded-lg border-l-4 border-blue-400">
                    <h3 className="font-semibold text-blue-800 mb-4">
                      <i className="ri-lungs-line mr-2"></i>
                      Respiration cohérente (Heart Rate Variability)
                    </h3>
                    <p className="text-blue-700 mb-4">Technique respiratoire qui synchronise le cœur, le mental et les émotions.</p>
                    <div className="bg-white p-4 rounded-lg">
                      <h4 className="font-medium text-blue-800 mb-2">Protocol :</h4>
                      <ol className="space-y-1 text-blue-700 text-sm">
                        <li>1. Inspirez pendant 5 secondes</li>
                        <li>2. Expirez pendant 5 secondes</li>
                        <li>3. Maintenez ce rythme pendant 5-20 minutes</li>
                        <li>4. Focalisez-vous sur la région du cœur</li>
                      </ol>
                    </div>
                  </div>

                  <div className="bg-green-50 p-6 rounded-lg border-l-4 border-green-400">
                    <h3 className="font-semibold text-green-800 mb-4">
                      <i className="ri-scan-line mr-2"></i>
                      Body Scan progressif
                    </h3>
                    <p className="text-green-700 mb-4">Relaxation profonde par balayage corporel conscient.</p>
                    <div className="bg-white p-4 rounded-lg">
                      <h4 className="font-medium text-green-800 mb-2">Étapes :</h4>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-green-700 text-sm font-medium mb-1">Phase 1 (5 min)</p>
                          <p className="text-green-700 text-sm">Pieds → Jambes → Bassin</p>
                        </div>
                        <div>
                          <p className="text-green-700 text-sm font-medium mb-1">Phase 2 (5 min)</p>
                          <p className="text-green-700 text-sm">Abdomen → Torse → Bras</p>
                        </div>
                        <div>
                          <p className="text-green-700 text-sm font-medium mb-1">Phase 3 (5 min)</p>
                          <p className="text-green-700 text-sm">Épaules → Cou → Tête</p>
                        </div>
                        <div>
                          <p className="text-green-700 text-sm font-medium mb-1">Phase 4 (5 min)</p>
                          <p className="text-green-700 text-sm">Corps entier en unité</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-purple-50 p-6 rounded-lg border-l-4 border-purple-400">
                    <h3 className="font-semibold text-purple-800 mb-4">
                      <i className="ri-emotion-line mr-2"></i>
                      RAIN (pour les émotions difficiles)
                    </h3>
                    <p className="text-purple-700 mb-4">Technique pour accueillir et transformer les émotions de stress.</p>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="bg-white p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center mr-3">
                            <span className="text-white font-bold text-sm">R</span>
                          </div>
                          <h4 className="font-medium text-purple-800">Reconnaître</h4>
                        </div>
                        <p className="text-purple-700 text-sm">Identifier l'émotion présente</p>
                      </div>
                      <div className="bg-white p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center mr-3">
                            <span className="text-white font-bold text-sm">A</span>
                          </div>
                          <h4 className="font-medium text-purple-800">Accueillir</h4>
                        </div>
                        <p className="text-purple-700 text-sm">Permettre à l'émotion d'être là</p>
                      </div>
                      <div className="bg-white p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center mr-3">
                            <span className="text-white font-bold text-sm">I</span>
                          </div>
                          <h4 className="font-medium text-purple-800">Investiguer</h4>
                        </div>
                        <p className="text-purple-700 text-sm">Explorer avec bienveillance</p>
                      </div>
                      <div className="bg-white p-4 rounded-lg">
                        <div className="flex items-center mb-2">
                          <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center mr-3">
                            <span className="text-white font-bold text-sm">N</span>
                          </div>
                          <h4 className="font-medium text-purple-800">Non-identification</h4>
                        </div>
                        <p className="text-purple-700 text-sm">Se détacher de l'émotion</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-orange-50 p-6 rounded-lg border-l-4 border-orange-400">
                    <h3 className="font-semibold text-orange-800 mb-4">
                      <i className="ri-timer-line mr-2"></i>
                      Méditation micro (1-3 minutes)
                    </h3>
                    <p className="text-orange-700 mb-4">Techniques ultra-courtes pour les moments de stress intense.</p>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="bg-white p-3 rounded-lg text-center">
                        <h5 className="font-medium text-orange-800 mb-1">STOP</h5>
                        <p className="text-orange-700 text-xs">Arrêt • Respiration • Observation • Perspective</p>
                      </div>
                      <div className="bg-white p-3 rounded-lg text-center">
                        <h5 className="font-medium text-orange-800 mb-1">5-4-3-2-1</h5>
                        <p className="text-orange-700 text-xs">Ancrage sensoriel rapide</p>
                      </div>
                      <div className="bg-white p-3 rounded-lg text-center">
                        <h5 className="font-medium text-orange-800 mb-1">Box Breathing</h5>
                        <p className="text-orange-700 text-xs">4 temps égaux</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Section 3: Intégration quotidienne */}
          {activeSection === 'integration' && (
            <div className="space-y-6">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-calendar-check-line text-indigo-600 text-xl"></i>
                </div>
                <h2 className="text-2xl font-bold text-gray-800">Intégration dans la vie quotidienne</h2>
              </div>

              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed mb-6">
                  La véritable transformation survient quand la pleine conscience s'intègre naturellement dans votre quotidien, devenant une façon d'être plutôt qu'une pratique isolée.
                </p>

                <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-8 rounded-xl my-8">
                  <h3 className="text-xl font-bold text-gray-800 mb-6 text-center">Programme progressif 21 jours</h3>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="bg-white p-4 rounded-lg">
                      <h4 className="font-semibold text-indigo-800 mb-3">Semaine 1 : Fondations</h4>
                      <ul className="space-y-2 text-indigo-700 text-sm">
                        <li>• Jour 1-3 : Respiration consciente (5 min)</li>
                        <li>• Jour 4-5 : Body scan court (10 min)</li>
                        <li>• Jour 6-7 : Méditation assise (15 min)</li>
                      </ul>
                    </div>
                    <div className="bg-white p-4 rounded-lg">
                      <h4 className="font-semibold text-purple-800 mb-3">Semaine 2 : Expansion</h4>
                      <ul className="space-y-2 text-purple-700 text-sm">
                        <li>• Jour 8-10 : Marche méditative</li>
                        <li>• Jour 11-12 : Méditation des émotions</li>
                        <li>• Jour 13-14 : Pleine conscience alimentaire</li>
                      </ul>
                    </div>
                    <div className="bg-white p-4 rounded-lg">
                      <h4 className="font-semibold text-pink-800 mb-3">Semaine 3 : Intégration</h4>
                      <ul className="space-y-2 text-pink-700 text-sm">
                        <li>• Jour 15-17 : Moments informels</li>
                        <li>• Jour 18-19 : Gestion du stress aigu</li>
                        <li>• Jour 20-21 : Pratique autonome</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-green-50 p-6 rounded-lg my-8">
                  <h3 className="font-semibold text-green-800 mb-4">Moments de pleine conscience informelle</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium text-green-800 mb-3">Au quotidien</h4>
                      <ul className="space-y-1 text-green-700 text-sm">
                        <li>• Se brosser les dents consciemment</li>
                        <li>• Écouter pleinement les autres</li>
                        <li>• Savourer la première gorgée de café</li>
                        <li>• Respirer consciemment dans les transports</li>
                        <li>• Marcher en pleine présence</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium text-green-800 mb-3">Au travail</h4>
                      <ul className="space-y-1 text-green-700 text-sm">
                        <li>• Pause respiration entre deux tâches</li>
                        <li>• Écoute consciente en réunion</li>
                        <li>• Micro-méditations aux toilettes</li>
                        <li>• Répondre aux emails avec présence</li>
                        <li>• Transitions mindful entre activités</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 p-6 rounded-lg my-8">
                  <h3 className="font-semibold text-blue-800 mb-4">Applications et outils recommandés</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-white p-4 rounded-lg">
                      <h4 className="font-medium text-blue-800 mb-2">Applications mobile</h4>
                      <ul className="space-y-1 text-blue-700 text-sm">
                        <li>• Headspace (débutants)</li>
                        <li>• Insight Timer (communauté)</li>
                        <li>• Calm (sommeil et relaxation)</li>
                        <li>• Ten Percent Happier (pragmatique)</li>
                      </ul>
                    </div>
                    <div className="bg-white p-4 rounded-lg">
                      <h4 className="font-medium text-blue-800 mb-2">Accessoires utiles</h4>
                      <ul className="space-y-1 text-blue-700 text-sm">
                        <li>• Coussin de méditation</li>
                        <li>• Minuteur avec gong</li>
                        <li>• Casque antibruit</li>
                        <li>• Journal de pratique</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 my-8">
                  <h3 className="font-semibold text-yellow-800 mb-3">Surmonter les obstacles courants</h3>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-yellow-800">"Je n'ai pas le temps"</h4>
                      <p className="text-yellow-700 text-sm">Commencez par 2 minutes. La régularité prime sur la durée.</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-yellow-800">"Mon mental est trop agité"</h4>
                      <p className="text-yellow-700 text-sm">C'est normal ! L'agitation mentale est justement ce que la pratique apaise.</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-yellow-800">"Je ne ressens rien"</h4>
                      <p className="text-yellow-700 text-sm">Les bienfaits sont souvent subtils. Persistez sans attendre d'effets spectaculaires.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="mt-8 flex justify-between items-center">
          <Link href="/chapitre-1" className="flex items-center text-indigo-600 hover:text-indigo-700 transition-colors cursor-pointer">
            <i className="ri-arrow-left-line mr-2"></i>
            Chapitre 1 : Neurosciences
          </Link>
          <Link href="/chapitre-3" className="flex items-center bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
            Chapitre 3 : Nutrition
            <i className="ri-arrow-right-line ml-2"></i>
          </Link>
        </div>
      </div>
    </div>
  );
}