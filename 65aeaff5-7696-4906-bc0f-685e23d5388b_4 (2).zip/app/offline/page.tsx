'use client';

import Link from 'next/link';

export default function OfflinePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center px-4">
      <div className="text-center max-w-md mx-auto">
        <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <i className="ri-wifi-off-line text-indigo-600 text-3xl"></i>
        </div>
        
        <h1 className="text-2xl font-bold text-gray-800 mb-4">
          Mode hors-ligne
        </h1>
        
        <p className="text-gray-600 mb-8">
          Vous êtes actuellement hors-ligne. Les pages que vous avez déjà visitées restent accessibles.
        </p>
        
        <Link href="/" className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer inline-block">
          Retour à l'accueil
        </Link>
      </div>
    </div>
  );
}