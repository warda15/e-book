'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Bonus() {
  const [activeTab, setActiveTab] = useState('glossaire');
  const [expandedCase, setExpandedCase] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-100">
      {/* Header Navigation */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-amber-600 cursor-pointer">
              <span className="font-['Pacifico']">StressWell</span>
            </Link>
            <div className="flex items-center space-x-6">
              <Link href="/table-des-matieres" className="text-gray-600 hover:text-amber-600 transition-colors cursor-pointer">Table des matières</Link>
              <Link href="/outils-pratiques" className="text-gray-600 hover:text-amber-600 transition-colors cursor-pointer">Outils</Link>
              <Link href="/ressources" className="text-gray-600 hover:text-amber-600 transition-colors cursor-pointer">Ressources</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center bg-amber-100 text-amber-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <i className="ri-gift-line mr-2"></i>
            Section Bonus
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            Ressources complémentaires
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Glossaire, FAQ et études de cas inspirantes pour approfondir votre compréhension et votre pratique
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab('glossaire')}
              className={`flex-1 px-6 py-4 text-center font-medium transition-colors ${
                activeTab === 'glossaire'
                  ? 'bg-amber-500 text-white'
                  : 'text-gray-600 hover:text-amber-600 hover:bg-amber-50'
              }`}
            >
              <i className="ri-book-open-line mr-2"></i>
              Glossaire
            </button>
            <button
              onClick={() => setActiveTab('faq')}
              className={`flex-1 px-6 py-4 text-center font-medium transition-colors ${
                activeTab === 'faq'
                  ? 'bg-amber-500 text-white'
                  : 'text-gray-600 hover:text-amber-600 hover:bg-amber-50'
              }`}
            >
              <i className="ri-question-answer-line mr-2"></i>
              FAQ
            </button>
            <button
              onClick={() => setActiveTab('etudes-cas')}
              className={`flex-1 px-6 py-4 text-center font-medium transition-colors ${
                activeTab === 'etudes-cas'
                  ? 'bg-amber-500 text-white'
                  : 'text-gray-600 hover:text-amber-600 hover:bg-amber-50'
              }`}
            >
              <i className="ri-user-star-line mr-2"></i>
              Études de cas
            </button>
          </div>

          {/* Glossaire Tab */}
          {activeTab === 'glossaire' && (
            <div className="p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i className="ri-book-open-line text-amber-600 mr-3"></i>
                Glossaire des termes clés
              </h2>
              
              <div className="space-y-4">
                {[
                  {
                    term: "Cortisol",
                    definition: "Hormone du stress produite par les glandes surrénales. Essential à court terme, il devient problématique lorsqu'il reste élevé de façon chronique."
                  },
                  {
                    term: "Neuroplasticité",
                    definition: "Capacité du cerveau à se réorganiser et créer de nouvelles connexions neuronales tout au long de la vie. C'est ce qui rend possible l'apprentissage de nouvelles habitudes."
                  },
                  {
                    term: "Mindfulness",
                    definition: "État de conscience où l'attention est portée intentionnellement sur le moment présent, sans jugement. Traduit par 'pleine conscience' en français."
                  },
                  {
                    term: "Système nerveux autonome",
                    definition: "Partie du système nerveux qui contrôle les fonctions automatiques du corps (respiration, rythme cardiaque, digestion). Comprend les systèmes sympathique et parasympathique."
                  },
                  {
                    term: "Résilience",
                    definition: "Capacité à s'adapter et à récupérer face aux difficultés, au stress et aux traumatismes. C'est une compétence qui se développe avec la pratique."
                  },
                  {
                    term: "Amygdale",
                    definition: "Structure cérébrale en forme d'amande qui traite les émotions, particulièrement la peur. Elle déclenche la réponse de 'combat ou fuite' face au danger."
                  },
                  {
                    term: "L-théanine",
                    definition: "Acide aminé présent dans le thé vert qui favorise la relaxation sans somnolence et améliore la concentration."
                  },
                  {
                    term: "Cohérence cardiaque",
                    definition: "État d'équilibre physiologique obtenu par une respiration rythmée qui synchronise le rythme cardiaque avec la respiration."
                  },
                  {
                    term: "Hormèse",
                    definition: "Phénomène par lequel une exposition faible à un stress stimule les mécanismes d'adaptation et renforce la résistance."
                  },
                  {
                    term: "GABA",
                    definition: "Neurotransmetteur inhibiteur principal du cerveau, responsable de la relaxation et de la réduction de l'anxiété."
                  }
                ].map((item, index) => (
                  <div key={index} className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <h3 className="font-semibold text-amber-800 mb-2">{item.term}</h3>
                    <p className="text-amber-700 text-sm">{item.definition}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* FAQ Tab */}
          {activeTab === 'faq' && (
            <div className="p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i className="ri-question-answer-line text-amber-600 mr-3"></i>
                Questions fréquemment posées
              </h2>
              
              <div className="space-y-4">
                {[
                  {
                    question: "Combien de temps faut-il pour voir les premiers résultats ?",
                    answer: "Les techniques de respiration peuvent avoir un effet immédiat. Pour les changements plus profonds (méditation, habitudes alimentaires), comptez 2-4 semaines de pratique régulière. La neuroplasticité commence à agir dès les premiers jours, mais les changements durables nécessitent de la constance."
                  },
                  {
                    question: "Que faire si je n'arrive pas à méditer ou à me concentrer ?",
                    answer: "C'est tout à fait normal ! Commencez par 2-3 minutes seulement. L'objectif n'est pas d'avoir l'esprit vide, mais de remarquer quand vous êtes distrait et de ramener doucement votre attention. Chaque retour à la respiration est une victoire, pas un échec."
                  },
                  {
                    question: "Ces techniques fonctionnent-elles pour l'anxiété généralisée ?",
                    answer: "Oui, mais en complément d'un suivi professionnel si nécessaire. Les techniques de ce guide sont excellentes pour gérer le stress quotidien et peuvent significativement aider avec l'anxiété. Pour des troubles anxieux sévères, consultez un professionnel de santé."
                  },
                  {
                    question: "Comment maintenir la motivation sur le long terme ?",
                    answer: "Commencez petit (5 min/jour), suivez vos progrès dans un journal, trouvez un partenaire de pratique, et célébrez chaque petite victoire. Rappelez-vous pourquoi vous avez commencé et ajustez vos techniques selon vos besoins."
                  },
                  {
                    question: "Puis-je adapter ces techniques à ma vie professionnelle ?",
                    answer: "Absolument ! Intégrez des micro-pauses respiratoires, utilisez la technique STOP entre les réunions, pratiquez la marche consciente sur le trajet, et créez des rituels de transition entre travail et vie personnelle."
                  },
                  {
                    question: "Que faire en cas de rechute ou de période difficile ?",
                    answer: "Les rechutes sont normales et font partie du processus. Revenez aux bases (respiration, pleine conscience), soyez bienveillant avec vous-même, et n'hésitez pas à demander de l'aide. Une rechute n'annule pas vos progrès précédents."
                  },
                  {
                    question: "Comment savoir quelle technique me convient le mieux ?",
                    answer: "Expérimentez pendant 2 semaines chaque technique qui vous attire. Notez vos ressentis et l'efficacité perçue. Votre corps et votre intuition vous guideront vers ce qui vous convient le mieux."
                  },
                  {
                    question: "Ces techniques sont-elles compatibles avec un traitement médical ?",
                    answer: "Oui, ces techniques sont complémentaires aux traitements médicaux. Elles ne les remplacent pas. Informez toujours votre médecin de vos pratiques de gestion du stress, surtout si vous prenez des médicaments."
                  }
                ].map((item, index) => (
                  <div key={index} className="bg-blue-50 border border-blue-200 rounded-lg">
                    <button
                      onClick={() => setExpandedCase(expandedCase === `faq-${index}` ? null : `faq-${index}`)}
                      className="w-full p-4 text-left flex items-center justify-between hover:bg-blue-100 transition-colors"
                    >
                      <h3 className="font-semibold text-blue-800">{item.question}</h3>
                      <i className={`ri-arrow-${expandedCase === `faq-${index}` ? 'up' : 'down'}-line text-blue-600`}></i>
                    </button>
                    {expandedCase === `faq-${index}` && (
                      <div className="px-4 pb-4">
                        <p className="text-blue-700 text-sm leading-relaxed">{item.answer}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Études de cas Tab */}
          {activeTab === 'etudes-cas' && (
            <div className="p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i className="ri-user-star-line text-amber-600 mr-3"></i>
                Études de cas inspirantes
              </h2>
              
              <div className="space-y-6">
                {[
                  {
                    name: "Marie, 35 ans - Cadre en entreprise",
                    situation: "Stress chronique, insomnies, épuisement professionnel imminent",
                    intervention: "Méditation matinale 10 min + techniques de respiration + optimisation du sommeil",
                    resultat: "Réduction de 60% du stress perçu en 6 semaines, amélioration du sommeil, promotion obtenue avec sérénité",
                    color: "purple"
                  },
                  {
                    name: "Thomas, 28 ans - Étudiant en médecine",
                    situation: "Anxiété avant les examens, difficultés de concentration, procrastination",
                    intervention: "Technique STOP + pleine conscience + journal de stress + cohérence cardiaque",
                    resultat: "Amélioration des performances académiques, réduction de l'anxiété de 70%, gestion sereine des examens",
                    color: "blue"
                  },
                  {
                    name: "Sophie, 42 ans - Mère de famille et entrepreneure",
                    situation: "Surcharge mentale, difficultés à concilier famille et travail, irritabilité",
                    intervention: "Micro-pauses conscientes + nutrition anti-stress + exercice régulier + limites saines",
                    resultat: "Meilleur équilibre vie pro/perso, relations familiales apaisées, énergie retrouvée",
                    color: "green"
                  },
                  {
                    name: "Jean, 55 ans - En reconversion professionnelle",
                    situation: "Stress du changement, peur de l'échec, troubles du sommeil",
                    intervention: "Visualisation positive + marche méditative + réseau de soutien + acceptation du changement",
                    resultat: "Reconversion réussie, confiance retrouvée, nouvelle passion découverte",
                    color: "orange"
                  },
                  {
                    name: "Léa, 24 ans - Jeune active en ville",
                    situation: "Stress urbain, surconnexion numérique, relations sociales superficielles",
                    intervention: "Détox numérique partielle + nature thérapie + méditation guidée + activités créatives",
                    resultat: "Bien-être mental amélioré, relations plus authentiques, créativité épanouie",
                    color: "pink"
                  }
                ].map((cas, index) => (
                  <div key={index} className={`bg-${cas.color}-50 border border-${cas.color}-200 rounded-lg overflow-hidden`}>
                    <button
                      onClick={() => setExpandedCase(expandedCase === `case-${index}` ? null : `case-${index}`)}
                      className={`w-full p-4 text-left flex items-center justify-between hover:bg-${cas.color}-100 transition-colors`}
                    >
                      <div>
                        <h3 className={`font-semibold text-${cas.color}-800`}>{cas.name}</h3>
                        <p className={`text-sm text-${cas.color}-600 mt-1`}>{cas.situation}</p>
                      </div>
                      <i className={`ri-arrow-${expandedCase === `case-${index}` ? 'up' : 'down'}-line text-${cas.color}-600`}></i>
                    </button>
                    {expandedCase === `case-${index}` && (
                      <div className="px-4 pb-4 space-y-3">
                        <div>
                          <h4 className={`font-medium text-${cas.color}-800 mb-1`}>🎯 Intervention mise en place :</h4>
                          <p className={`text-sm text-${cas.color}-700`}>{cas.intervention}</p>
                        </div>
                        <div>
                          <h4 className={`font-medium text-${cas.color}-800 mb-1`}>✨ Résultats obtenus :</h4>
                          <p className={`text-sm text-${cas.color}-700`}>{cas.resultat}</p>
                        </div>
                        <div className={`bg-${cas.color}-100 p-3 rounded`}>
                          <p className={`text-xs text-${cas.color}-600 italic`}>
                            💡 Point clé : La constance dans la pratique et l'adaptation des techniques à la situation personnelle ont été déterminantes pour le succès.
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className="mt-8 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg p-6">
                <h3 className="text-xl font-bold mb-3 flex items-center">
                  <i className="ri-lightbulb-flash-line mr-2"></i>
                  Points communs des réussites
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center">
                      <i className="ri-check-line mr-2 text-green-300"></i>
                      Commencer petit et progresser graduellement
                    </li>
                    <li className="flex items-center">
                      <i className="ri-check-line mr-2 text-green-300"></i>
                      Pratiquer quotidiennement, même 5 minutes
                    </li>
                    <li className="flex items-center">
                      <i className="ri-check-line mr-2 text-green-300"></i>
                      Adapter les techniques à sa situation unique
                    </li>
                  </ul>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center">
                      <i className="ri-check-line mr-2 text-green-300"></i>
                      Suivre ses progrès et célébrer les victoires
                    </li>
                    <li className="flex items-center">
                      <i className="ri-check-line mr-2 text-green-300"></i>
                      S'entourer de personnes bienveillantes
                    </li>
                    <li className="flex items-center">
                      <i className="ri-check-line mr-2 text-green-300"></i>
                      Persévérer malgré les difficultés temporaires
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center mt-8">
          <Link href="/conclusion" className="flex items-center text-amber-600 hover:text-amber-700 transition-colors cursor-pointer">
            <i className="ri-arrow-left-line mr-2"></i>
            Conclusion
          </Link>
          <Link href="/table-des-matieres" className="text-gray-500 hover:text-gray-700 transition-colors cursor-pointer">
            Table des matières
          </Link>
          <Link href="/ressources" className="flex items-center text-amber-600 hover:text-amber-700 transition-colors cursor-pointer">
            Ressources
            <i className="ri-arrow-right-line ml-2"></i>
          </Link>
        </div>
      </div>
    </div>
  );
}