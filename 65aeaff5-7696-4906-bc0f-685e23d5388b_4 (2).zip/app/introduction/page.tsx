
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Introduction() {
  const [activeSection, setActiveSection] = useState('enjeu');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-indigo-600 cursor-pointer">
              <span className="font-['Pacifico']">StressWell</span>
            </Link>
            <div className="flex items-center space-x-6">
              <Link href="/table-des-matieres" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">Table des matières</Link>
              <Link href="/chapitre-1" className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors whitespace-nowrap cursor-pointer">Chapitre suivant</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Chapter Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Introduction</h1>
          <p className="text-lg text-gray-600">Le stress moderne : un défi majeur qui nécessite des solutions avancées</p>
        </div>

        {/* Navigation Pills */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          <button
            onClick={() => setActiveSection('enjeu')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeSection === 'enjeu' 
                ? 'bg-indigo-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-indigo-50'
            }`}
          >
            L'enjeu du stress
          </button>
          <button
            onClick={() => setActiveSection('importance')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeSection === 'importance' 
                ? 'bg-indigo-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-indigo-50'
            }`}
          >
            Approches holistiques
          </button>
          <button
            onClick={() => setActiveSection('objectifs')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeSection === 'objectifs' 
                ? 'bg-indigo-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-indigo-50'
            }`}
          >
            Objectifs de l'ebook
          </button>
        </div>

        {/* Content Sections */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Section 1: L'enjeu du stress */}
          {activeSection === 'enjeu' && (
            <div className="space-y-6">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-alert-line text-red-600 text-xl"></i>
                </div>
                <h2 className="text-2xl font-bold text-gray-800">L'enjeu majeur du stress dans la vie moderne</h2>
              </div>

              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed mb-6">
                  Le stress est devenu l'épidémie silencieuse de notre époque. Dans un monde hyperconnecté, où les sollicitations sont constantes et les rythmes effrénés, notre système nerveux est en état d'alerte permanent.
                </p>

                <div className="bg-blue-50 border-l-4 border-blue-400 p-6 my-8">
                  <h3 className="font-semibold text-blue-800 mb-3">Chiffres alarmants</h3>
                  <ul className="space-y-2 text-blue-700">
                    <li>• 75% des français déclarent ressentir du stress au quotidien</li>
                    <li>• Le stress chronique augmente de 40% le risque de maladies cardiovasculaires</li>
                    <li>• 1 actif sur 4 souffre de troubles du sommeil liés au stress</li>
                    <li>• Le coût du stress au travail : 3,2 milliards d'euros par an en France</li>
                  </ul>
                </div>

                <p className="text-gray-700 leading-relaxed mb-6">
                  Ce qui était autrefois un mécanisme de survie ponctuel est devenu une réponse chronique face aux défis modernes : pression professionnelle, surcharge informationnelle, isolement social, incertitudes économiques...
                </p>

                <div className="grid md:grid-cols-2 gap-6 my-8">
                  <div className="bg-orange-50 p-6 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-3">Stress aigu (naturel)</h4>
                    <p className="text-orange-700 text-sm">Réaction ponctuelle face à un danger réel, suivie d'une phase de récupération</p>
                  </div>
                  <div className="bg-red-50 p-6 rounded-lg">
                    <h4 className="font-semibold text-red-800 mb-3">Stress chronique (problématique)</h4>
                    <p className="text-red-700 text-sm">État d'activation permanent sans phase de récupération, épuisant l'organisme</p>
                  </div>
                </div>

                <p className="text-gray-700 leading-relaxed">
                  Les méthodes traditionnelles de gestion du stress, bien qu'utiles, s'avèrent souvent insuffisantes face à cette nouvelle réalité. Il nous faut des approches plus sophistiquées, fondées sur la science moderne et adaptées à nos modes de vie contemporains.
                </p>
              </div>
            </div>
          )}

          {/* Section 2: Importance des approches holistiques */}
          {activeSection === 'importance' && (
            <div className="space-y-6">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-heart-pulse-line text-green-600 text-xl"></i>
                </div>
                <h2 className="text-2xl font-bold text-gray-800">L'importance d'une gestion avancée et holistique</h2>
              </div>

              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed mb-6">
                  La révolution neuroscientifique des dernières décennies nous permet aujourd'hui de comprendre précisément comment le stress affecte notre cerveau et notre corps. Cette connaissance ouvre la voie à des interventions ciblées et efficaces.
                </p>

                <div className="grid md:grid-cols-3 gap-6 my-8">
                  <div className="text-center p-6 bg-blue-50 rounded-lg">
                    <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-brain-line text-white text-2xl"></i>
                    </div>
                    <h4 className="font-semibold text-blue-800 mb-2">Neurosciences</h4>
                    <p className="text-blue-700 text-sm">Comprendre les mécanismes cérébraux pour agir efficacement</p>
                  </div>
                  <div className="text-center p-6 bg-green-50 rounded-lg">
                    <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-leaf-line text-white text-2xl"></i>
                    </div>
                    <h4 className="font-semibold text-green-800 mb-2">Pleine conscience</h4>
                    <p className="text-green-700 text-sm">Techniques millénaires validées par la recherche moderne</p>
                  </div>
                  <div className="text-center p-6 bg-orange-50 rounded-lg">
                    <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-restaurant-line text-white text-2xl"></i>
                    </div>
                    <h4 className="font-semibold text-orange-800 mb-2">Nutrition</h4>
                    <p className="text-orange-700 text-sm">L'alimentation comme médecine préventive du stress</p>
                  </div>
                </div>

                <div className="bg-indigo-50 border-l-4 border-indigo-400 p-6 my-8">
                  <h3 className="font-semibold text-indigo-800 mb-3">Pourquoi une approche holistique ?</h3>
                  <p className="text-indigo-700 mb-4">
                    Le stress affecte simultanément notre cerveau, notre corps et notre comportement. Une approche fragmentée ne peut donc donner des résultats optimaux.
                  </p>
                  <ul className="space-y-2 text-indigo-700">
                    <li>• Synergie des différentes méthodes pour un effet démultiplié</li>
                    <li>• Adaptation personnalisée selon le profil de chacun</li>
                    <li>• Durabilité des résultats grâce à des changements profonds</li>
                    <li>• Prévention plutôt que simple réaction au stress</li>
                  </ul>
                </div>

                <p className="text-gray-700 leading-relaxed">
                  Cette approche intégrée ne se contente pas de "gérer" le stress, elle vise à développer une véritable résilience : la capacité à rebondir face aux défis et même à croître grâce à eux.
                </p>
              </div>
            </div>
          )}

          {/* Section 3: Objectifs de l'ebook */}
          {activeSection === 'objectifs' && (
            <div className="space-y-6">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-target-line text-purple-600 text-xl"></i>
                </div>
                <h2 className="text-2xl font-bold text-gray-800">Objectifs de cet ebook</h2>
              </div>

              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed mb-6">
                  Cet ebook n'est pas un simple manuel théorique. C'est un guide pratique conçu pour vous accompagner dans une transformation durable de votre relation au stress.
                </p>

                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white font-bold text-sm">1</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-2">Découvrir les mécanismes du stress</h4>
                      <p className="text-gray-600">Comprendre ce qui se passe dans votre cerveau et votre corps quand vous êtes stressé, pour mieux agir.</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white font-bold text-sm">2</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-2">Maîtriser des techniques avancées</h4>
                      <p className="text-gray-600">Apprendre des méthodes de méditation, respiration et régulation émotionnelle adaptées à votre vie moderne.</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white font-bold text-sm">3</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-2">Optimiser votre nutrition anti-stress</h4>
                      <p className="text-gray-600">Découvrir les aliments et nutriments qui soutiennent votre résilience mentale.</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white font-bold text-sm">4</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-2">Créer votre stratégie personnalisée</h4>
                      <p className="text-gray-600">Élaborer un plan d'action adapté à votre profil, vos contraintes et vos objectifs.</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white font-bold text-sm">5</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-2">Maintenir les bénéfices à long terme</h4>
                      <p className="text-gray-600">Développer des habitudes durables et des outils de suivi pour pérenniser vos progrès.</p>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-8 rounded-xl my-8 text-center">
                  <h3 className="text-xl font-bold text-purple-800 mb-4">Votre transformation commence maintenant</h3>
                  <p className="text-purple-700 mb-6">
                    En appliquant les techniques de cet ebook, vous ne vous contenterez pas de survivre au stress : vous développerez une capacité remarquable à prospérer, même dans l'adversité.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Link href="/chapitre-1" className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
                      Commencer le Chapitre 1
                    </Link>
                    <Link href="/outils-pratiques" className="bg-white hover:bg-gray-50 text-purple-600 border border-purple-200 px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
                      Voir les outils pratiques
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="mt-8 flex justify-between items-center">
          <Link href="/table-des-matieres" className="flex items-center text-indigo-600 hover:text-indigo-700 transition-colors cursor-pointer">
            <i className="ri-arrow-left-line mr-2"></i>
            Retour à la table des matières
          </Link>
          <Link href="/chapitre-1" className="flex items-center bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
            Chapitre 1 : Neurosciences du stress
            <i className="ri-arrow-right-line ml-2"></i>
          </Link>
        </div>
      </div>
    </div>
  );
}
