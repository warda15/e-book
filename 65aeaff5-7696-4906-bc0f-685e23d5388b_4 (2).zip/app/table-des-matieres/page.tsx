
'use client';

import Link from 'next/link';

export default function TableDesMatieres() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-indigo-600 cursor-pointer">
              <span className="font-['Pacifico']">StressWell</span>
            </Link>
            <div className="flex items-center space-x-6">
              <Link href="/introduction" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">Introduction</Link>
              <Link href="/outils-pratiques" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">Outils</Link>
              <Link href="/ressources" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">Ressources</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Page Title */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Table des Matières</h1>
          <p className="text-lg text-gray-600">Navigation interactive vers tous les chapitres</p>
        </div>

        {/* Table of Contents */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Introduction */}
          <div className="mb-8 pb-6 border-b border-gray-100">
            <Link href="/introduction" className="block hover:bg-gray-50 rounded-lg p-4 transition-colors cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">Introduction</h3>
                  <p className="text-gray-600">L'enjeu majeur du stress moderne et les approches holistiques</p>
                </div>
                <i className="ri-arrow-right-line text-indigo-500 text-xl"></i>
              </div>
            </Link>
          </div>

          {/* Chapters */}
          <div className="space-y-6">
            <Link href="/chapitre-1" className="block hover:bg-gray-50 rounded-lg p-4 transition-colors cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">
                    <span className="text-indigo-600 mr-3">Chapitre 1</span>
                    Comprendre le stress au niveau neuroscientifique
                  </h3>
                  <p className="text-gray-600">Mécanismes cérébraux, impact du stress chronique et dernières découvertes</p>
                  <div className="flex items-center mt-2 text-sm text-gray-500">
                    <i className="ri-time-line mr-1"></i>
                    <span>15 min de lecture</span>
                    <span className="mx-2">•</span>
                    <i className="ri-bookmark-line mr-1"></i>
                    <span>3 exercices pratiques</span>
                  </div>
                </div>
                <i className="ri-arrow-right-line text-indigo-500 text-xl"></i>
              </div>
            </Link>

            <Link href="/chapitre-2" className="block hover:bg-gray-50 rounded-lg p-4 transition-colors cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">
                    <span className="text-indigo-600 mr-3">Chapitre 2</span>
                    Mindfulness et méditation avancées
                  </h3>
                  <p className="text-gray-600">Principes de pleine conscience et techniques adaptées au stress quotidien</p>
                  <div className="flex items-center mt-2 text-sm text-gray-500">
                    <i className="ri-time-line mr-1"></i>
                    <span>20 min de lecture</span>
                    <span className="mx-2">•</span>
                    <i className="ri-bookmark-line mr-1"></i>
                    <span>5 méditations guidées</span>
                  </div>
                </div>
                <i className="ri-arrow-right-line text-indigo-500 text-xl"></i>
              </div>
            </Link>

            <Link href="/chapitre-3" className="block hover:bg-gray-50 rounded-lg p-4 transition-colors cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">
                    <span className="text-indigo-600 mr-3">Chapitre 3</span>
                    Nutrition et habitudes de vie pour la résilience
                  </h3>
                  <p className="text-gray-600">Alimentation anti-stress, micronutriments et routines optimales</p>
                  <div className="flex items-center mt-2 text-sm text-gray-500">
                    <i className="ri-time-line mr-1"></i>
                    <span>18 min de lecture</span>
                    <span className="mx-2">•</span>
                    <i className="ri-bookmark-line mr-1"></i>
                    <span>Plans nutritionnels</span>
                  </div>
                </div>
                <i className="ri-arrow-right-line text-indigo-500 text-xl"></i>
              </div>
            </Link>

            <Link href="/chapitre-4" className="block hover:bg-gray-50 rounded-lg p-4 transition-colors cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">
                    <span className="text-indigo-600 mr-3">Chapitre 4</span>
                    Stratégie personnelle de résilience
                  </h3>
                  <p className="text-gray-600">Intégration pratique et plan d'action personnalisé</p>
                  <div className="flex items-center mt-2 text-sm text-gray-500">
                    <i className="ri-time-line mr-1"></i>
                    <span>12 min de lecture</span>
                    <span className="mx-2">•</span>
                    <i className="ri-bookmark-line mr-1"></i>
                    <span>Plan personnalisé</span>
                  </div>
                </div>
                <i className="ri-arrow-right-line text-indigo-500 text-xl"></i>
              </div>
            </Link>
          </div>

          {/* Additional Sections */}
          <div className="mt-8 pt-6 border-t border-gray-100 space-y-4">
            <Link href="/outils-pratiques" className="block hover:bg-gray-50 rounded-lg p-4 transition-colors cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">Exercices pratiques et outils</h3>
                  <p className="text-gray-600 text-sm">Fiches, journaux de suivi et checklists</p>
                </div>
                <i className="ri-arrow-right-line text-indigo-500 text-xl"></i>
              </div>
            </Link>

            <Link href="/conclusion" className="block hover:bg-gray-50 rounded-lg p-4 transition-colors cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">Conclusion</h3>
                  <p className="text-gray-600 text-sm">Synthèse et invitation à l'application durable</p>
                </div>
                <i className="ri-arrow-right-line text-indigo-500 text-xl"></i>
              </div>
            </Link>

            <Link href="/bonus" className="block hover:bg-gray-50 rounded-lg p-4 transition-colors cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">Bonus</h3>
                  <p className="text-gray-600 text-sm">Glossaire, FAQ et études de cas inspirantes</p>
                </div>
                <i className="ri-arrow-right-line text-indigo-500 text-xl"></i>
              </div>
            </Link>

            <Link href="/ressources" className="block hover:bg-gray-50 rounded-lg p-4 transition-colors cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">Ressources complémentaires</h3>
                  <p className="text-gray-600 text-sm">Liens, formations et communautés</p>
                </div>
                <i className="ri-arrow-right-line text-indigo-500 text-xl"></i>
              </div>
            </Link>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/introduction" className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors text-center whitespace-nowrap cursor-pointer">
            Commencer par l'introduction
          </Link>
          <Link href="/outils-pratiques" className="bg-white hover:bg-gray-50 text-indigo-600 border border-indigo-200 px-6 py-3 rounded-lg font-semibold transition-colors text-center whitespace-nowrap cursor-pointer">
            Accéder aux outils
          </Link>
        </div>
      </div>
    </div>
  );
}
