'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function OutilsPratiques() {
  const [activeCategory, setActiveCategory] = useState('evaluation');
  const [showExercise, setShowExercise] = useState(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-indigo-600 cursor-pointer">
              <span className="font-['Pacifico']">StressWell</span>
            </Link>
            <div className="flex items-center space-x-6">
              <Link href="/table-des-matieres" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">Table des matières</Link>
              <Link href="/ressources" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">Ressources</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Page Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Outils Pratiques</h1>
          <p className="text-lg text-gray-600">Exercices, fiches et ressources pour votre transformation</p>
        </div>

        {/* Category Navigation */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          <button
            onClick={() => setActiveCategory('evaluation')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeCategory === 'evaluation' 
                ? 'bg-purple-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-purple-50'
            }`}
          >
            Auto-évaluation
          </button>
          <button
            onClick={() => setActiveCategory('exercices')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeCategory === 'exercices' 
                ? 'bg-purple-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-purple-50'
            }`}
          >
            Exercices pratiques
          </button>
          <button
            onClick={() => setActiveCategory('suivi')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeCategory === 'suivi' 
                ? 'bg-purple-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-purple-50'
            }`}
          >
            Journaux de suivi
          </button>
          <button
            onClick={() => setActiveCategory('urgence')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeCategory === 'urgence' 
                ? 'bg-purple-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-purple-50'
            }`}
          >
            Kit d'urgence
          </button>
        </div>

        {/* Content Sections */}
        <div className="space-y-8">
          {/* Auto-évaluation */}
          {activeCategory === 'evaluation' && (
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-survey-line text-blue-600"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800">Échelle de stress perçu</h3>
                </div>
                <p className="text-gray-600 mb-4">Évaluez votre niveau de stress des 4 dernières semaines</p>
                
                <div className="space-y-3">
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm text-gray-700 mb-2">1. À quelle fréquence avez-vous été bouleversé par un événement inattendu ?</p>
                    <div className="flex space-x-2">
                      <button className="px-3 py-1 bg-gray-200 hover:bg-blue-200 rounded text-xs cursor-pointer">Jamais</button>
                      <button className="px-3 py-1 bg-gray-200 hover:bg-blue-200 rounded text-xs cursor-pointer">Parfois</button>
                      <button className="px-3 py-1 bg-gray-200 hover:bg-blue-200 rounded text-xs cursor-pointer">Souvent</button>
                      <button className="px-3 py-1 bg-gray-200 hover:bg-blue-200 rounded text-xs cursor-pointer">Très souvent</button>
                    </div>
                  </div>
                  <div className="text-center">
                    <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm cursor-pointer whitespace-nowrap">
                      Continuer l'évaluation complète
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-heart-pulse-line text-green-600"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800">Profil de résilience</h3>
                </div>
                <p className="text-gray-600 mb-4">Identifiez vos forces et axes d'amélioration</p>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Gestion émotionnelle</span>
                    <div className="w-24 bg-gray-200 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full w-3/4"></div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Adaptabilité</span>
                    <div className="w-24 bg-gray-200 rounded-full h-2">
                      <div className="bg-yellow-500 h-2 rounded-full w-1/2"></div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Support social</span>
                    <div className="w-24 bg-gray-200 rounded-full h-2">
                      <div className="bg-blue-500 h-2 rounded-full w-5/6"></div>
                    </div>
                  </div>
                  <button className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg text-sm cursor-pointer whitespace-nowrap">
                    Faire le test complet
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Exercices pratiques */}
          {activeCategory === 'exercices' && (
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-lungs-line text-blue-600"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-800">Respiration 4-7-8</h3>
                </div>
                <p className="text-gray-600 text-sm mb-4">Technique de relaxation rapide pour l'anxiété</p>
                
                <button 
                  onClick={() => setShowExercise(showExercise === '478' ? null : '478')}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg text-sm cursor-pointer whitespace-nowrap mb-4"
                >
                  {showExercise === '478' ? 'Masquer' : 'Commencer l\'exercice'}
                </button>
                
                {showExercise === '478' && (
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-800 mb-2">Phase : Inspiration</div>
                      <div className="text-lg text-blue-600 mb-3">Comptez jusqu'à 4</div>
                      <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-3">
                        <i className="ri-arrow-down-line text-white text-xl"></i>
                      </div>
                      <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-1 rounded text-sm cursor-pointer whitespace-nowrap">
                        Suivant : Rétention (7s)
                      </button>
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-body-scan-line text-green-600"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-800">Scan corporel 5 min</h3>
                </div>
                <p className="text-gray-600 text-sm mb-4">Relaxation musculaire progressive guidée</p>
                
                <button 
                  onClick={() => setShowExercise(showExercise === 'scan' ? null : 'scan')}
                  className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg text-sm cursor-pointer whitespace-nowrap mb-4"
                >
                  {showExercise === 'scan' ? 'Arrêter' : 'Lancer la séance'}
                </button>
                
                {showExercise === 'scan' && (
                  <div className="bg-green-50 p-4 rounded-lg">
                    <div className="text-center">
                      <div className="text-lg font-semibold text-green-800 mb-2">Étape 1/5 : Pieds</div>
                      <p className="text-green-700 text-sm mb-3">Concentrez-vous sur vos pieds. Ressentez-les se détendre...</p>
                      <div className="w-full bg-green-200 rounded-full h-2 mb-3">
                        <div className="bg-green-500 h-2 rounded-full w-1/5"></div>
                      </div>
                      <audio controls className="w-full">
                        <source src="/audio/body-scan.mp3" type="audio/mpeg" />
                      </audio>
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-emotion-line text-purple-600"></i>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-800">RAIN émotionnel</h3>
                </div>
                <p className="text-gray-600 text-sm mb-4">Technique pour gérer les émotions difficiles</p>
                
                <button className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-lg text-sm cursor-pointer whitespace-nowrap mb-4">
                  Guide interactif
                </button>
                
                <div className="space-y-2">
                  <div className="flex items-center text-sm">
                    <div className="w-4 h-4 bg-purple-500 rounded-full mr-2 flex items-center justify-center">
                      <span className="text-white text-xs">R</span>
                    </div>
                    <span className="text-gray-700">Reconnaître l'émotion</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <div className="w-4 h-4 bg-purple-500 rounded-full mr-2 flex items-center justify-center">
                      <span className="text-white text-xs">A</span>
                    </div>
                    <span className="text-gray-700">Accueillir sans jugement</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <div className="w-4 h-4 bg-purple-500 rounded-full mr-2 flex items-center justify-center">
                      <span className="text-white text-xs">I</span>
                    </div>
                    <span className="text-gray-700">Investiguer avec bienveillance</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <div className="w-4 h-4 bg-purple-500 rounded-full mr-2 flex items-center justify-center">
                      <span className="text-white text-xs">N</span>
                    </div>
                    <span className="text-gray-700">Non-identification</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Journaux de suivi */}
          {activeCategory === 'suivi' && (
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-calendar-line text-orange-600"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800">Journal de stress quotidien</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium text-gray-800 mb-3">Aujourd'hui - Mercredi 15 Jan</h4>
                    <div className="space-y-3">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Niveau de stress (1-10)</label>
                        <input type="range" min="1" max="10" className="w-full" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Déclencheurs principaux</label>
                        <textarea className="w-full p-2 border rounded-lg text-sm" rows="2" placeholder="Ex: Réunion difficile, embouteillages..."></textarea>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Techniques utilisées</label>
                        <div className="flex flex-wrap gap-2">
                          <button className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs cursor-pointer">Respiration</button>
                          <button className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs cursor-pointer">Méditation</button>
                          <button className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-xs cursor-pointer">Exercice</button>
                        </div>
                      </div>
                    </div>
                    <button className="w-full bg-orange-600 hover:bg-orange-700 text-white py-2 rounded-lg text-sm mt-4 cursor-pointer whitespace-nowrap">
                      Sauvegarder l'entrée
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-line-chart-line text-teal-600"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800">Progression hebdomadaire</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="bg-teal-50 p-4 rounded-lg">
                    <h4 className="font-medium text-teal-800 mb-3">Cette semaine</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-teal-700">Stress moyen</span>
                        <span className="font-semibold text-teal-800">6.2/10</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-teal-700">Pratiques réalisées</span>
                        <span className="font-semibold text-teal-800">12/14</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-teal-700">Amélioration</span>
                        <span className="font-semibold text-green-600">-0.8 pts</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium text-gray-800 mb-3">Graphique des 30 derniers jours</h4>
                    <div className="h-32 bg-white rounded border flex items-end justify-around p-2">
                      <div className="w-4 bg-red-400 h-3/4 rounded-t"></div>
                      <div className="w-4 bg-orange-400 h-2/3 rounded-t"></div>
                      <div className="w-4 bg-yellow-400 h-1/2 rounded-t"></div>
                      <div className="w-4 bg-green-400 h-1/3 rounded-t"></div>
                      <div className="w-4 bg-green-500 h-1/4 rounded-t"></div>
                    </div>
                    <p className="text-xs text-gray-600 text-center mt-2">Tendance décroissante 📈</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Kit d'urgence */}
          {activeCategory === 'urgence' && (
            <div className="bg-white rounded-xl shadow-lg p-8">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mr-4">
                  <i className="ri-alarm-warning-line text-red-600 text-xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-800">Kit d'urgence anti-stress</h3>
              </div>
              
              <p className="text-gray-600 mb-8">Techniques rapides pour les moments de stress intense</p>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-red-50 p-6 rounded-lg border border-red-200">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-time-line text-white text-2xl"></i>
                    </div>
                    <h4 className="font-semibold text-red-800 mb-2">STOP (30 secondes)</h4>
                    <p className="text-red-700 text-sm mb-4">Arrêt immédiat de l'escalade</p>
                    <button className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm cursor-pointer whitespace-nowrap">
                      Utiliser maintenant
                    </button>
                  </div>
                </div>
                
                <div className="bg-orange-50 p-6 rounded-lg border border-orange-200">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-focus-3-line text-white text-2xl"></i>
                    </div>
                    <h4 className="font-semibold text-orange-800 mb-2">5-4-3-2-1 (2 minutes)</h4>
                    <p className="text-orange-700 text-sm mb-4">Ancrage sensoriel rapide</p>
                    <button className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg text-sm cursor-pointer whitespace-nowrap">
                      Commencer
                    </button>
                  </div>
                </div>
                
                <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-lungs-line text-white text-2xl"></i>
                    </div>
                    <h4 className="font-semibold text-blue-800 mb-2">Box Breathing (3 minutes)</h4>
                    <p className="text-blue-700 text-sm mb-4">Régulation du système nerveux</p>
                    <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm cursor-pointer whitespace-nowrap">
                      Respirer
                    </button>
                  </div>
                </div>
                
                <div className="bg-green-50 p-6 rounded-lg border border-green-200">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-phone-line text-white text-2xl"></i>
                    </div>
                    <h4 className="font-semibold text-green-800 mb-2">Contacts d'urgence</h4>
                    <p className="text-green-700 text-sm mb-4">Soutien professionnel immédiat</p>
                    <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm cursor-pointer whitespace-nowrap">
                      Voir les numéros
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="mt-8 bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-lg">
                <h4 className="font-semibold text-yellow-800 mb-3">
                  <i className="ri-lightbulb-line mr-2"></i>
                  Conseil d'urgence
                </h4>
                <p className="text-yellow-700">
                  En cas de stress overwhelmant, rappelez-vous : <strong>ce moment passera</strong>. 
                  Utilisez d'abord la technique STOP, puis choisissez l'outil qui vous convient le mieux selon votre état.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="mt-12 flex justify-center">
          <Link href="/table-des-matieres" className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
            Retour à la table des matières
          </Link>
        </div>
      </div>
    </div>
  );
}