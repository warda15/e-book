'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Ressources() {
  const [activeTab, setActiveTab] = useState('formations');

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-cyan-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-indigo-600 cursor-pointer">
              <span className="font-['Pacifico']">StressWell</span>
            </Link>
            <div className="flex items-center space-x-6">
              <Link href="/table-des-matieres" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">Table des matières</Link>
              <Link href="/outils-pratiques" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">Outils pratiques</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Page Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Ressources Complémentaires</h1>
          <p className="text-lg text-gray-600">Formations, applications et communautés pour approfondir votre pratique</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          <button
            onClick={() => setActiveTab('formations')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'formations' 
                ? 'bg-teal-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-teal-50'
            }`}
          >
            Formations
          </button>
          <button
            onClick={() => setActiveTab('applications')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'applications' 
                ? 'bg-teal-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-teal-50'
            }`}
          >
            Applications
          </button>
          <button
            onClick={() => setActiveTab('livres')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'livres' 
                ? 'bg-teal-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-teal-50'
            }`}
          >
            Livres
          </button>
          <button
            onClick={() => setActiveTab('communautes')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'communautes' 
                ? 'bg-teal-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-teal-50'
            }`}
          >
            Communautés
          </button>
          <button
            onClick={() => setActiveTab('professionnels')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'professionnels' 
                ? 'bg-teal-600 text-white' 
                : 'bg-white text-gray-600 hover:bg-teal-50'
            }`}
          >
            Professionnels
          </button>
        </div>

        {/* Content Sections */}
        <div className="space-y-8">
          {/* Formations */}
          {activeTab === 'formations' && (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <img 
                  src="https://readdy.ai/api/search-image?query=mindfulness%20teacher%20in%20peaceful%20meditation%20classroom%2C%20professional%20training%20environment%2C%20students%20learning%20meditation%20techniques%2C%20serene%20educational%20setting%2C%20wellness%20instructor%20certification%20program&width=400&height=200&seq=mbsr-training&orientation=landscape"
                  alt="Formation MBSR"
                  className="w-full h-48 object-cover object-top"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">MBSR - Réduction du Stress</h3>
                  <p className="text-gray-600 text-sm mb-4">Programme de 8 semaines basé sur la pleine conscience, créé par Jon Kabat-Zinn</p>
                  <div className="flex items-center justify-between mb-4">
                    <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-medium">Certifié</span>
                    <span className="text-lg font-bold text-gray-800">8 semaines</span>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center text-sm text-gray-600">
                      <i className="ri-map-pin-line mr-2"></i>
                      <span>Centre de méditation Paris</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <i className="ri-calendar-line mr-2"></i>
                      <span>Prochaine session : Mars 2024</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <i className="ri-price-tag-line mr-2"></i>
                      <span>450€ (prise en charge possible)</span>
                    </div>
                  </div>
                  <button className="w-full bg-teal-600 hover:bg-teal-700 text-white py-2 rounded-lg mt-4 cursor-pointer whitespace-nowrap">
                    Plus d'informations
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <img 
                  src="https://readdy.ai/api/search-image?query=online%20mindfulness%20course%20on%20laptop%20screen%2C%20digital%20wellness%20education%2C%20virtual%20meditation%20training%2C%20e-learning%20platform%20for%20stress%20management%2C%20modern%20online%20education%20setup&width=400&height=200&seq=online-mindfulness&orientation=landscape"
                  alt="Formation en ligne"
                  className="w-full h-48 object-cover object-top"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">Mindfulness Online</h3>
                  <p className="text-gray-600 text-sm mb-4">Formation complète en ligne avec accompagnement personnalisé</p>
                  <div className="flex items-center justify-between mb-4">
                    <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs font-medium">En ligne</span>
                    <span className="text-lg font-bold text-gray-800">Flexible</span>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center text-sm text-gray-600">
                      <i className="ri-video-line mr-2"></i>
                      <span>40h de contenu vidéo</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <i className="ri-group-line mr-2"></i>
                      <span>Sessions de groupe hebdomadaires</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <i className="ri-price-tag-line mr-2"></i>
                      <span>290€ (accès à vie)</span>
                    </div>
                  </div>
                  <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg mt-4 cursor-pointer whitespace-nowrap">
                    Commencer maintenant
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <img 
                  src="https://readdy.ai/api/search-image?query=workplace%20wellness%20workshop%2C%20corporate%20stress%20management%20training%2C%20professional%20team%20learning%20mindfulness%2C%20office%20meditation%20session%2C%20business%20wellness%20program&width=400&height=200&seq=corporate-wellness&orientation=landscape"
                  alt="Formation entreprise"
                  className="w-full h-48 object-cover object-top"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">Bien-être en Entreprise</h3>
                  <p className="text-gray-600 text-sm mb-4">Ateliers sur mesure pour réduire le stress au travail</p>
                  <div className="flex items-center justify-between mb-4">
                    <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-xs font-medium">Sur mesure</span>
                    <span className="text-lg font-bold text-gray-800">1-3 jours</span>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center text-sm text-gray-600">
                      <i className="ri-building-line mr-2"></i>
                      <span>Dans vos locaux</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <i className="ri-team-line mr-2"></i>
                      <span>Jusqu'à 20 participants</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <i className="ri-phone-line mr-2"></i>
                      <span>Devis sur demande</span>
                    </div>
                  </div>
                  <button className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-lg mt-4 cursor-pointer whitespace-nowrap">
                    Demander un devis
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Applications */}
          {activeTab === 'applications' && (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-smartphone-line text-orange-600 text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Headspace</h3>
                    <div className="flex items-center">
                      <div className="flex text-yellow-400">
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-half-line text-sm"></i>
                      </div>
                      <span className="text-xs text-gray-600 ml-1">4.8</span>
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-4">Méditations guidées pour débutants et experts</p>
                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-xs text-gray-600">
                    <i className="ri-check-line text-green-500 mr-1"></i>
                    <span>Programme de base gratuit</span>
                  </div>
                  <div className="flex items-center text-xs text-gray-600">
                    <i className="ri-check-line text-green-500 mr-1"></i>
                    <span>Méditations thématiques</span>
                  </div>
                  <div className="flex items-center text-xs text-gray-600">
                    <i className="ri-check-line text-green-500 mr-1"></i>
                    <span>Suivi des progrès</span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button className="flex-1 bg-gray-900 text-white py-2 px-3 rounded text-xs cursor-pointer whitespace-nowrap">
                    App Store
                  </button>
                  <button className="flex-1 bg-green-600 text-white py-2 px-3 rounded text-xs cursor-pointer whitespace-nowrap">
                    Play Store
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-timer-line text-blue-600 text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Insight Timer</h3>
                    <div className="flex items-center">
                      <div className="flex text-yellow-400">
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-line text-sm"></i>
                      </div>
                      <span className="text-xs text-gray-600 ml-1">4.2</span>
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-4">Plus grande bibliothèque de méditations gratuites</p>
                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-xs text-gray-600">
                    <i className="ri-check-line text-green-500 mr-1"></i>
                    <span>80,000+ méditations gratuites</span>
                  </div>
                  <div className="flex items-center text-xs text-gray-600">
                    <i className="ri-check-line text-green-500 mr-1"></i>
                    <span>Communauté mondiale</span>
                  </div>
                  <div className="flex items-center text-xs text-gray-600">
                    <i className="ri-check-line text-green-500 mr-1"></i>
                    <span>Minuteur personnalisable</span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button className="flex-1 bg-gray-900 text-white py-2 px-3 rounded text-xs cursor-pointer whitespace-nowrap">
                    App Store
                  </button>
                  <button className="flex-1 bg-green-600 text-white py-2 px-3 rounded text-xs cursor-pointer whitespace-nowrap">
                    Play Store
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-moon-line text-purple-600 text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">Calm</h3>
                    <div className="flex items-center">
                      <div className="flex text-yellow-400">
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                      </div>
                      <span className="text-xs text-gray-600 ml-1">4.9</span>
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-4">Spécialisé dans le sommeil et la relaxation</p>
                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-xs text-gray-600">
                    <i className="ri-check-line text-green-500 mr-1"></i>
                    <span>Histoires pour dormir</span>
                  </div>
                  <div className="flex items-center text-xs text-gray-600">
                    <i className="ri-check-line text-green-500 mr-1"></i>
                    <span>Sons de la nature</span>
                  </div>
                  <div className="flex items-center text-xs text-gray-600">
                    <i className="ri-check-line text-green-500 mr-1"></i>
                    <span>Masterclasses bien-être</span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button className="flex-1 bg-gray-900 text-white py-2 px-3 rounded text-xs cursor-pointer whitespace-nowrap">
                    App Store
                  </button>
                  <button className="flex-1 bg-green-600 text-white py-2 px-3 rounded text-xs cursor-pointer whitespace-nowrap">
                    Play Store
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mr-3">
                    <i className="ri-heart-pulse-line text-red-600 text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">HeartMath</h3>
                    <div className="flex items-center">
                      <div className="flex text-yellow-400">
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-line text-sm"></i>
                      </div>
                      <span className="text-xs text-gray-600 ml-1">4.1</span>
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-4">Cohérence cardiaque scientifique</p>
                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-xs text-gray-600">
                    <i className="ri-check-line text-green-500 mr-1"></i>
                    <span>Mesure HRV en temps réel</span>
                  </div>
                  <div className="flex items-center text-xs text-gray-600">
                    <i className="ri-check-line text-green-500 mr-1"></i>
                    <span>Exercices de cohérence</span>
                  </div>
                  <div className="flex items-center text-xs text-gray-600">
                    <i className="ri-check-line text-green-500 mr-1"></i>
                    <span>Capteur optionnel</span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button className="flex-1 bg-gray-900 text-white py-2 px-3 rounded text-xs cursor-pointer whitespace-nowrap">
                    App Store
                  </button>
                  <button className="flex-1 bg-green-600 text-white py-2 px-3 rounded text-xs cursor-pointer whitespace-nowrap">
                    Play Store
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Livres */}
          {activeTab === 'livres' && (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex mb-4">
                  <img 
                    src="https://readdy.ai/api/search-image?query=mindfulness%20book%20cover%20design%2C%20peaceful%20meditation%20theme%2C%20professional%20wellness%20publication%2C%20zen-inspired%20book%20layout%2C%20calming%20blue%20and%20green%20colors%2C%20stress%20reduction%20guide&width=120&height=160&seq=mindfulness-book&orientation=portrait"
                    alt="Livre mindfulness"
                    className="w-20 h-28 object-cover rounded mr-4 object-top"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800 mb-1">Au cœur de la tourmente, la pleine conscience</h3>
                    <p className="text-sm text-gray-600 mb-2">Jon Kabat-Zinn</p>
                    <div className="flex items-center mb-2">
                      <div className="flex text-yellow-400">
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                      </div>
                      <span className="text-xs text-gray-600 ml-1">4.7/5</span>
                    </div>
                    <p className="text-xs text-gray-600">Référence mondiale de la mindfulness appliquée au stress</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Prix livre</span>
                    <span className="font-semibold">24,90€</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Version numérique</span>
                    <span className="font-semibold">16,99€</span>
                  </div>
                </div>
                <div className="flex space-x-2 mt-4">
                  <button className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-2 px-3 rounded text-sm cursor-pointer whitespace-nowrap">
                    Amazon
                  </button>
                  <button className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-3 rounded text-sm cursor-pointer whitespace-nowrap">
                    Fnac
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex mb-4">
                  <img 
                    src="https://readdy.ai/api/search-image?query=neuroscience%20book%20cover%20about%20stress%20and%20brain%2C%20scientific%20medical%20publication%2C%20modern%20psychology%20book%20design%2C%20brain%20illustration%2C%20professional%20academic%20style&width=120&height=160&seq=neuroscience-stress-book&orientation=portrait"
                    alt="Livre neurosciences"
                    className="w-20 h-28 object-cover rounded mr-4 object-top"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800 mb-1">Pourquoi le stress nous fait du bien</h3>
                    <p className="text-sm text-gray-600 mb-2">Kelly McGonigal</p>
                    <div className="flex items-center mb-2">
                      <div className="flex text-yellow-400">
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-line text-sm"></i>
                      </div>
                      <span className="text-xs text-gray-600 ml-1">4.3/5</span>
                    </div>
                    <p className="text-xs text-gray-600">Révolution scientifique sur notre perception du stress</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Prix livre</span>
                    <span className="font-semibold">22,90€</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Version numérique</span>
                    <span className="font-semibold">14,99€</span>
                  </div>
                </div>
                <div className="flex space-x-2 mt-4">
                  <button className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-2 px-3 rounded text-sm cursor-pointer whitespace-nowrap">
                    Amazon
                  </button>
                  <button className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-3 rounded text-sm cursor-pointer whitespace-nowrap">
                    Fnac
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex mb-4">
                  <img 
                    src="https://readdy.ai/api/search-image?query=resilience%20psychology%20book%20cover%2C%20mental%20strength%20and%20adaptation%2C%20self-help%20wellness%20publication%2C%20empowering%20book%20design%2C%20positive%20psychology%20theme&width=120&height=160&seq=resilience-book&orientation=portrait"
                    alt="Livre résilience"
                    className="w-20 h-28 object-cover rounded mr-4 object-top"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800 mb-1">La Force de l'optimisme</h3>
                    <p className="text-sm text-gray-600 mb-2">Martin Seligman</p>
                    <div className="flex items-center mb-2">
                      <div className="flex text-yellow-400">
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-fill text-sm"></i>
                        <i className="ri-star-half-line text-sm"></i>
                      </div>
                      <span className="text-xs text-gray-600 ml-1">4.5/5</span>
                    </div>
                    <p className="text-xs text-gray-600">Fondements de la psychologie positive et de la résilience</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Prix livre</span>
                    <span className="font-semibold">25,90€</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Version numérique</span>
                    <span className="font-semibold">17,99€</span>
                  </div>
                </div>
                <div className="flex space-x-2 mt-4">
                  <button className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-2 px-3 rounded text-sm cursor-pointer whitespace-nowrap">
                    Amazon
                  </button>
                  <button className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-3 rounded text-sm cursor-pointer whitespace-nowrap">
                    Fnac
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Communautés */}
          {activeTab === 'communautes' && (
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                    <i className="ri-group-line text-blue-600 text-xl"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800">Forums et Groupes</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-800">Mindfulness France</h4>
                      <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">12.5k membres</span>
                    </div>
                    <p className="text-gray-600 text-sm mb-3">Communauté francophone dédiée à la pleine conscience</p>
                    <div className="flex space-x-2">
                      <button className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm cursor-pointer whitespace-nowrap">
                        Rejoindre Facebook
                      </button>
                      <button className="text-blue-600 hover:text-blue-700 px-3 py-1 text-sm cursor-pointer whitespace-nowrap">
                        Site web
                      </button>
                    </div>
                  </div>
                  
                  <div className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-800">r/Meditation</h4>
                      <span className="bg-orange-100 text-orange-800 px-2 py-1 rounded-full text-xs">850k membres</span>
                    </div>
                    <p className="text-gray-600 text-sm mb-3">Subreddit international sur la méditation</p>
                    <div className="flex space-x-2">
                      <button className="bg-orange-600 hover:bg-orange-700 text-white px-3 py-1 rounded text-sm cursor-pointer whitespace-nowrap">
                        Voir sur Reddit
                      </button>
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-800">Telegram StressWell</h4>
                      <span className="bg-purple-100 text-purple-800 px-2 py-1 rounded-full text-xs">2.1k membres</span>
                    </div>
                    <p className="text-gray-600 text-sm mb-3">Groupe privé pour partager expériences et conseils</p>
                    <div className="flex space-x-2">
                      <button className="bg-purple-600 hover:bg-purple-700 text-white px-3 py-1 rounded text-sm cursor-pointer whitespace-nowrap">
                        Rejoindre
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                    <i className="ri-calendar-event-line text-green-600 text-xl"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800">Événements à venir</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="border-l-4 border-green-400 bg-green-50 p-4 rounded">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-green-800">Retraite Mindfulness</h4>
                      <span className="text-green-600 text-sm">Mars 15-17, 2024</span>
                    </div>
                    <p className="text-green-700 text-sm mb-2">Week-end intensif en Normandie</p>
                    <div className="flex items-center text-sm text-green-600">
                      <i className="ri-map-pin-line mr-1"></i>
                      <span>Abbaye de Bec-Hellouin</span>
                    </div>
                  </div>
                  
                  <div className="border-l-4 border-blue-400 bg-blue-50 p-4 rounded">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-blue-800">Conférence Neurosciences</h4>
                      <span className="text-blue-600 text-sm">Avril 5, 2024</span>
                    </div>
                    <p className="text-blue-700 text-sm mb-2">Dernières découvertes sur le stress</p>
                    <div className="flex items-center text-sm text-blue-600">
                      <i className="ri-map-pin-line mr-1"></i>
                      <span>Cité des Sciences, Paris</span>
                    </div>
                  </div>
                  
                  <div className="border-l-4 border-purple-400 bg-purple-50 p-4 rounded">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-purple-800">Cercle de méditation</h4>
                      <span className="text-purple-600 text-sm">Chaque mardi</span>
                    </div>
                    <p className="text-purple-700 text-sm mb-2">Sessions hebdomadaires guidées</p>
                    <div className="flex items-center text-sm text-purple-600">
                      <i className="ri-video-line mr-1"></i>
                      <span>En ligne - 19h30</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Professionnels */}
          {activeTab === 'professionnels' && (
            <div className="space-y-8">
              <div className="bg-white rounded-xl shadow-lg p-8">
                <h3 className="text-2xl font-bold text-gray-800 mb-6">Trouver un professionnel près de chez vous</h3>
                
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="border border-gray-200 rounded-lg p-6">
                    <div className="flex items-center mb-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                        <i className="ri-user-heart-line text-blue-600 text-xl"></i>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">Psychologues</h4>
                        <p className="text-sm text-gray-600">Thérapies cognitivo-comportementales</p>
                      </div>
                    </div>
                    <ul className="space-y-2 text-sm text-gray-600 mb-4">
                      <li>• Gestion du stress et anxiété</li>
                      <li>• Thérapies TCC spécialisées</li>
                      <li>• Séances individuelles ou groupe</li>
                      <li>• Remboursement partiel possible</li>
                    </ul>
                    <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg cursor-pointer whitespace-nowrap">
                      Trouver un psychologue
                    </button>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-6">
                    <div className="flex items-center mb-4">
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                        <i className="ri-leaf-line text-green-600 text-xl"></i>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">Instructeurs MBSR</h4>
                        <p className="text-sm text-gray-600">Mindfulness-Based Stress Reduction</p>
                      </div>
                    </div>
                    <ul className="space-y-2 text-sm text-gray-600 mb-4">
                      <li>• Programmes certifiés 8 semaines</li>
                      <li>• Formation spécialisée validée</li>
                      <li>• Approche laïque et scientifique</li>
                      <li>• Groupes ou sessions individuelles</li>
                    </ul>
                    <button className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg cursor-pointer whitespace-nowrap">
                      Annuaire MBSR
                    </button>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-6">
                    <div className="flex items-center mb-4">
                      <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                        <i className="ri-heart-pulse-line text-purple-600 text-xl"></i>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">Coachs HeartMath</h4>
                        <p className="text-sm text-gray-600">Cohérence cardiaque</p>
                      </div>
                    </div>
                    <ul className="space-y-2 text-sm text-gray-600 mb-4">
                      <li>• Mesure objective du stress</li>
                      <li>• Techniques de cohérence cardiaque</li>
                      <li>• Biofeedback en temps réel</li>
                      <li>• Approche scientifique validée</li>
                    </ul>
                    <button className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-lg cursor-pointer whitespace-nowrap">
                      Trouver un coach
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-lg">
                <h4 className="font-semibold text-yellow-800 mb-3">
                  <i className="ri-information-line mr-2"></i>
                  Remboursements et prise en charge
                </h4>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h5 className="font-medium text-yellow-800 mb-2">Sécurité Sociale</h5>
                    <ul className="text-yellow-700 text-sm space-y-1">
                      <li>• Psychologues : dispositif MonParcoursPsy</li>
                      <li>• Remboursement jusqu'à 8 séances/an</li>
                      <li>• Sur prescription médecin traitant</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-medium text-yellow-800 mb-2">Mutuelles</h5>
                    <ul className="text-yellow-700 text-sm space-y-1">
                      <li>• Forfait bien-être de 50-200€/an</li>
                      <li>• Thérapies alternatives incluses</li>
                      <li>• Vérifiez votre contrat</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="mt-12 flex justify-center">
          <Link href="/table-des-matieres" className="bg-teal-600 hover:bg-teal-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
            Retour à la table des matières
          </Link>
        </div>
      </div>
    </div>
  );
}