
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="text-2xl font-bold text-indigo-600 cursor-pointer">
            <span className="font-['Pacifico']">StressWell</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/table-des-matieres" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">
              Table des matières
            </Link>
            <Link href="/introduction" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">
              Introduction
            </Link>
            <Link href="/outils-pratiques" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">
              Outils pratiques
            </Link>
            <Link href="/ressources" className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer">
              Ressources
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg text-gray-600 hover:text-indigo-600 hover:bg-gray-100 transition-colors cursor-pointer"
          >
            <div className="w-6 h-6 flex items-center justify-center">
              <i className={`ri-${isMenuOpen ? 'close' : 'menu'}-line text-xl`}></i>
            </div>
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-100">
            <div className="flex flex-col space-y-4">
              <Link 
                href="/table-des-matieres" 
                className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer"
                onClick={() => setIsMenuOpen(false)}
              >
                Table des matières
              </Link>
              <Link 
                href="/introduction" 
                className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer"
                onClick={() => setIsMenuOpen(false)}
              >
                Introduction
              </Link>
              <Link 
                href="/outils-pratiques" 
                className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer"
                onClick={() => setIsMenuOpen(false)}
              >
                Outils pratiques
              </Link>
              <Link 
                href="/ressources" 
                className="text-gray-600 hover:text-indigo-600 transition-colors cursor-pointer"
                onClick={() => setIsMenuOpen(false)}
              >
                Ressources
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
